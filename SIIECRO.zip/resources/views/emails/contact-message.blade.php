
<h1>Emisor del correo:</h1> <br>
{{$datos}}

<h2>Nombre(s):</h2>
{{$nombres}}

<h3>contenido del correo:</h3> <br>
{{$msg}}

