@extends('adminlte::layouts.app')
 
@section('main-content')

<!--@if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>{{ $Obrasg->first()->id }}
@endif-->
<div class="box">
    <div class="box-body"  >
            <div class="panel">
                <h1>Registro de Análisis Científico: {{ $a_cientifico->id_obras }}
            
</h1>
                @if ($errors->any())
                <div class="alert alert-danger">
                    <strong>Vaya!</strong> Algo salio mal.<br><br>
                    <ul>
                        @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
                @endif
                <form action="{{ route('registro.actualizar', $a_cientifico->idcientifico) }}" method="POST" class="form-inline text-left" enctype="multipart/form-data">
                    @csrf 
                    <BR>
                    <div class="form-group">
                        <div class="form-group">
                            <div class="input-group" >
                                <label for="id_gene" class="input-group-addon">ID Solicitud </label>
                                <input type="text" name="id_gene" class="form-control"  value="{{ $a_cientifico->id_gene }}" style="width:200px" readonly><BR>    
                            </div>
                            <div class="input-group" >
                                <label for="id_obras" class="input-group-addon">ID Obra </label>
                                <input type="text" name="id_obras" class="form-control"  value="{{ $a_cientifico->id_obras }}" style="width:200px" readonly><BR>    
                            </div>
                            <div class="input-group" >
                                <label for="titulo_obra" class="input-group-addon">Titulo de la obra/pieza</label>
                                <input type="text" name="titulo_Obra" class="form-control"  value="{{ $a_cientifico->titulo_obra }}" style="width:200px" readonly><BR> 
                            </div>
                            <div class="input-group">
                                <span class="input-group-addon">Temporalidad</span>
                                <input type="text" name="temp_trabajo" class="form-control"  value="{{ $a_cientifico->temp_trabajo }}" style="width:200px" readonly>
                            </div>
                            </div><br><br>
                        
                            
                        <div class="form-group">
                             <div class="input-group">
                                <span class="input-group-addon">Temporalidad</span>
                                <input type="text" name="temp_trabajo" class="form-control"  value="{{ $a_cientifico->temp_trabajo }}" style="width:200px" readonly>
                            </div>
                            <div class="input-group ">
                                <label for="epoca_obra" class="input-group-addon">Epoca de la obra</label>
                                <input type="text" name="epoca" class="form-control"  value="{{ $a_cientifico->epoca }}" style="width:200px" readonly>
                            </div>                            
                            <div class="input-group">
                                <label for="lugar_proce_ori" class="input-group-addon">Lugar de procedencia original</label>
                                <input type="text" class="form-control"  name="lugar_p_origen"  value="{{ $a_cientifico->lugar_p_origen }}" style="width:200px"readonly>
                            </div>
                            
                        </div><br><br>
                    <div class="form-group">
                        <div class="input-group">
                                <label for="lugar_proce_act" class="input-group-addon">Lugar de procedencia actual</label>
                                <input type="text" class="form-control"  name="lugar_p_actual"  value="{{ $a_cientifico->lugar_p_actual }}" style="width:200px" readonly>
                            </div>
                    <div class="input-group">
                        <label for="proyecto_ecro" class="input-group-addon">Proyecto de la obra</label>
                        <input type="text" class="form-control"  name="proyecto_ecro"  value="{{ $a_cientifico->proyecto_ecro }}" style="width:200px" readonly>
                    </div>
                    <div class="input-group">
                        <label for="año_proyecto" class="input-group-addon">Año de proyecto de la obra</label>
                        <input type="text" class="form-control"  name="año_proyecto" value="{{ $a_cientifico->año_proyecto }}" style="width:200px" readonly>
                    </div>
                </div><br><br>
                    <div class="input-group">
                        <div class="input-group date">
                        <div class="input-group-addon">
                             <i class="fa fa-calendar"> Fecha de inicio</i>
                        </div>
                        <input type="date" class="form-control date" name="fecha_inicio" placeholder="mm/dd/aaaa (Fecha de entrada)" value="{{ $a_cientifico->fecha_inicio }}" style="width:262px" readonly>
                    </div>
                    </div>
                    </div><br><br><br>
                    <div class="form-group">
                    <div class="input-group">
                        <label for="tecnica" class="input-group-addon">Tecnica</label>
                        <input type="text" class="form-control"  name="tecnica" value="{{ $a_cientifico->tecnica }}" style="width:200px" readonly>
                    </div><br><br>
                    
                <div class="form-group">
                    <div class="input-group">
                        <label for="nomenclatura_muestra" class="input-group-addon">Nomenclatura de la muestra</label>
                        <input type="text" class="form-control"  name="nomenclatura_muestra" value="{{ $a_cientifico->nomenclatura_muestra }}" style="width:200px" readonly>
                    </div> 
                    <div class="input-group">
                        <label for="lugar_de_resguardo" class="input-group-addon">Lugar de Resguardo</label>
                        <input type="text" class="form-control"  name="lugar_de_resguardo" value="{{ $a_cientifico->lugar_de_resguardo }}" style="width:200px" readonly>
                    </div> 
                    <div class="input-group">
                        <label for="caracte_analisis" class="input-group-addon">Caracterizacion de analisis</label>
                        <input type="text" class="form-control"  name="caracte_analisis" value="{{ $a_cientifico->caracte_analisis }}" style="width:200px" readonly>
                    </div> 
                    </div><br><br>
                    <div class="input-group date">
                        <div class="input-group-addon">
                             <i class="fa fa-calendar"> Fecha de analisis cientifico</i>
                        </div>
                        <input type="date" class="form-control date" name="fecha_analisis_cientifico" value="{{ $a_cientifico->fecha_analisis_cientifico }}" style="width:262px" readonly>
                    </div> <br><br>  
                    <div class="form-group">
                    <div class="input-group">
                        <label for="profesor_responsable" class="input-group-addon">Profesor responsable</label>
                        <input type="text" class="form-control"  name="profesor_responsable" value="{{ $a_cientifico->profesor_responsable }}" style="width:200px" readonly>
                    </div> 
                    <div class="input-group">
                        <label for="persona_realizo_analisis" class="input-group-addon">Persona que realizo el analisis</label>
                        <input type="text" class="form-control"  name="persona_realizo_analisis" value="{{ $a_cientifico->persona_realizo_analisis }}" style="width:200px" readonly>
                    </div> 
                    <div class="input-group">
                        <label for="forma_obtencion_muestra" class="input-group-addon">Forma de obtencion de las muestras</label>
                        <input type="text" class="form-control"  name="forma_obtencion_muestra" value="{{ $a_cientifico->forma_obtencion_muestra }}" style="width:200px" readonly>
                    </div> 
                    </div><br><br>
                    <div class="form-group">
                    <div class="input-group">
                        <label for="esquema" class="input-group-addon">Esquema</label>
                        @if($a_cientifico->esquema == 'Sin imagen')
                        <input type="text" class="form-control"  name="respon_intervencion" border="0" value="Sin imagen" style="width:200px">
                        @else
                        <a align="center" target="_blank" href="http://127.0.0.1:8000/images/{{$a_cientifico->esquema}} "><img  width="400px" src="{{asset('images/'.$a_cientifico->esquema)}}" class=""></a>
                        @endif
                    </div><br><br>  
                    <div class="input-group">
                        <label for="indicaciones" class="input-group-addon">Indicaciones</label>
                        <input type="text" class="form-control"  name="indicaciones" value="{{ $a_cientifico->indicaciones }}" style="width:200px" readonly>
                    </div>      
                    </div><br><br>

                    <div class="form-group">
                    <div class="input-group">
                        <label for="tipo_material" class="input-group-addon">Tipo de material</label>
                        <input type="text" class="form-control"  name="tipo_material" value="{{ $a_cientifico->tipo_material }}" style="width:200px" readonly>
                    </div>
                    <div class="input-group">
                        <label for="descripcion" class="input-group-addon">Descripcion</label>
                        <input type="text" class="form-control"  name="descripcion" value="{{ $a_cientifico->descripcion }}" style="width:200px" readonly>
                    </div><br><br>
                    <div class="input-group">
                        <label for="microfotografia" class="input-group-addon">Microfotografia</label>
                        @if($a_cientifico->microfotografia == 'Sin imagen')
                        <input type="text" class="form-control"  name="respon_intervencion" border="0" value="Sin imagen" style="width:200px">
                        @else
                        <a align="center" target="_blank" href="http://127.0.0.1:8000/images/{{$a_cientifico->microfotografia}} "><img  width="400px" src="{{asset('images/'.$a_cientifico->microfotografia)}}" class=""></a>
                        @endif
                    </div>        
                    </div><br><br>
                    <div class="input-group">
                        <label for="info_definir" class="input-group-addon">Informacion por definir</label>
                        <input type="text" class="form-control"  name="info_definir" value="{{ $a_cientifico->info_definir }}" readonly>
                    </div><br><br>
                    <div class="form-group">
                    <div class="input-group">
                        <label for="analisis_microestructural" class="input-group-addon">Analisis microestructural</label>
                        <input type="text" class="form-control"  name="analisis_microestructural" value="{{ $a_cientifico->analisis_microestructural }}" readonly>
                    </div>
                    <div class="input-group">
                        <label for="analisis_microquimico" class="input-group-addon">Analisis microquimico</label>
                        <input type="text" class="form-control"  name="analisis_microquimico" value="{{ $a_cientifico->analisis_microquimico }}" readonly>
                    </div> 
                    <div class="input-group">
                        <label for="analisis_elemental" class="input-group-addon">Analisis microelemental</label>
                        <input type="text" class="form-control"  name="analisis_elemental" value="{{ $a_cientifico->analisis_elemental }}" readonly>
                    </div>
                    </div><br><br>
                    <div class="form-group">
                    <div class="input-group">
                        <label for="analisis_molecular" class="input-group-addon">Analisis molecular</label>
                        <input type="text" class="form-control"  name="analisis_molecular" value="{{ $a_cientifico->analisis_molecular }}" readonly>
                    </div>
                    <div class="input-group">
                        <label for="analisis_de_tincion" class="input-group-addon">Analisis de tincion</label>
                        <input type="text" class="form-control"  name="analisis_de_tincion" value="{{ $a_cientifico->analisis_de_tincion }}" readonly>
                    </div> 
                    <div class="input-group">
                        <label for="analisis_microbiologicos" class="input-group-addon">Analisis Microbiológicos</label>
                        <input type="text" class="form-control"  name="analisis_microbiologicos" value="{{ $a_cientifico->analisis_microbiologicos }}" readonly>
                    </div> 
                    <div class="input-group">
                        <label for="otros" class="input-group-addon">otros</label>
                        <input type="text" class="form-control"  name="otros" value="{{ $a_cientifico->otros }}" readonly>
                    </div>
                    </div><br><br>  
                    <div class="input-group">
                        <label for="resultado_interpretacion" class="input-group-addon">Resultados de Interpretación</label>
                        <input type="text" class="form-control"  name="resultado_interpretacion" value="{{ $a_cientifico->resultado_interpretacion }}" readonly>
                    </div>
                    <div class="input-group">
                        <label for="resultado_descripcion" class="input-group-addon">Resultados de Descripción</label>
                        <input type="text" class="form-control"  name="resultado_descripcion" value="{{ $a_cientifico->resultado_descripcion }}" readonly>
                    </div>
                    <div class="input-group">
                        <label for="resultado_conclucion_general" class="input-group-addon">Conclusión General</label>
                        <input type="text" class="form-control"  name="resultado_conclucion_general" value="{{ $a_cientifico->resultado_conclucion_general }}" readonly>
                    </div>
                    <div class="input-group">
                        <label for="interpretacion_particular" class="input-group-addon">Interpretación Particular</label>
                        <input type="text" class="form-control"  name="interpretacion_particular" value="{{ $a_cientifico->interpretacion_particular }}" readonly>
                    </div><br><br> 
                    <div class="col-md-12 text-center">
                            <a href="{{route('registro.index')}}" class="btn btn-danger btn-sm">Cancelar</a>
                    </div>
                </form>
        </div>
    </div>
</div>
@endsection