 
<?php $__env->startSection('main-content'); ?>

<!--<?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div><?php echo e($Obrasg->first()->id); ?>

<?php endif; ?>-->
<div class="box">
    <div class="box-body"  >
            <div class="panel" align="center">
                <h1>Editar Solicitud de Análisis Científico 
			
</h1>
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <strong>Vaya!</strong> Algo salio mal.<br><br>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
                <form action="<?php echo e(route('registro.actualizar', $a_cientifico->idcientifico)); ?>" method="POST" class="form-inline text-left" enctype="multipart/form-data">
                    <?php echo method_field('put'); ?>
                    <?php echo csrf_field(); ?> 
                    <br>
                    <input hidden="" type="text" name="id_gene" value="<?php echo e($a_cientifico->id_gene); ?>">
                    <div align="center">
                        <table style="width: 50%"  border="0">
                            <tr>
                                <th colspan="2" style="text-align:center; background-color: #7C858C; color:white;"><h3>Datos Generales</h3></th></tr>
                            <tr>
                                <td><label for="id_obras" class="input-group-addon" style="width: 400px">ID Obra </label></td>
                                <td><input type="text" name="id_obras" class="form-control"  value="<?php echo e($a_cientifico->id_obras); ?>" style="width:500px; text-align:center;" readonly></td>
                            </tr>
                            <tr>
                                <td><label class="input-group-addon">Titulo de la obra/pieza</label></td>
                                <td><input type="text" name="titulo_obra" class="form-control"  value="<?php echo e($a_cientifico->titulo_obra); ?>" style="width:500px; text-align:center;" readonly></td>
                            </tr>
                            <tr>
                                <td><label class="input-group-addon">Temporada de trabajo</label></td>
                                <td><input type="text" name="temporada_trabajo" class="form-control" value="<?php echo e($a_cientifico->temporada_trabajo); ?>" style="width:500px; text-align:center;" readonly></td>
                            </tr>
                            <?php if($a_cientifico->epoca_obra == NULL): ?>
                            <?php else: ?>
                            <tr>    
                                <td><label for="epoca" class="input-group-addon">Epoca de la obra</label></td>
                                <td><input type="text" name="epoca" class="form-control" value="<?php echo e($a_cientifico->epoca_obra); ?>" style="width:500px; text-align:center;" readonly></td>
                            </tr>
                            <?php endif; ?>
                            <tr>
                                <td><label class="input-group-addon">Año de latemporada de trabajo</label></td>
                                <td><input type="text" class="form-control"  name="anio_temporada"  value="<?php echo e($a_cientifico->anio_temporada); ?>" style="width:500px; text-align:center;" readonly></td>
                            </tr>
                            <tr>
                                <td style="text-align:center;"><i class="fa fa-calendar"> Fecha de inicio</i></td>
                                <td><input type="date" class="form-control date" name="fecha_inicio" placeholder="mm/dd/aaaa (Fecha de entrada)" value="<?php echo e($a_cientifico->fecha_inicio); ?>" style="width:500px; text-align:center;" readonly></td>
                            </tr>
                            <tr>
                                <td><label for="tecnica" class="input-group-addon">Tecnica</label></td>
                                <td><input type="text" class="form-control"  name="tecnica" value="<?php echo e($a_cientifico->tecnica); ?>" style="width:500px; text-align:center;" readonly></td>
                            </tr>
                            <tr>
                                <th colspan="2" style="text-align:center; background-color: #7C858C; color:white;"><h3>Datos de Intentificación de la Muestra</h3></th>
                            </tr>
                            <tr>
                            <tr>
                                <td><label for="nomenclatura_muestra" class="input-group-addon">Nomenclatura de la muestra</label></td>
                                <td><input type="text" class="form-control"  name="nomenclatura_muestra" value="<?php echo e($a_cientifico->nomenclatura_muestra); ?>" style="width:500px; text-align:center;" ></td>
                            </tr>
                            <tr>
                                <td><label for="lugar_de_resguardo" class="input-group-addon">Lugar de Resguardo</label></td>
                                <td><input type="text" class="form-control"  name="lugar_de_resguardo" value="<?php echo e($a_cientifico->lugar_de_resguardo); ?>" style="width:500px; text-align:center;" ></td>
                            </tr>
                            <tr>
                                <td><label for="caracte_analisis" class="input-group-addon">Caracterizacion de analisis</label></td>
                                <td><input type="text" class="form-control"  name="caracte_analisis" value="<?php echo e($a_cientifico->caracte_analisis); ?>" style="width:500px; text-align:center;" ></td>
                            </tr>
                            <tr>
                                <td style="text-align:center;"><i class="fa fa-calendar" > Fecha de analisis cientifico</i></td>
                                <td><input type="date" class="form-control date" name="fecha_analisis_cientifico" value="<?php echo e($a_cientifico->fecha_analisis_cientifico); ?>" style="width:500px; text-align:center;" ></td>
                            </tr>
                            <tr>
                                <td><label for="profesor_responsable" class="input-group-addon">Profesor responsable</label></td>
                                <td><input type="text" class="form-control"  name="profesor_responsable" value="<?php echo e($a_cientifico->profesor_responsable); ?>" style="width:500px; text-align:center;" ></td>
                            </tr>
                            <tr>
                                <td><label for="persona_realizo_analisis" class="input-group-addon">Persona que realizo el analisis</label></td>
                                <td><input type="text" class="form-control"  name="persona_realizo_analisis" value="<?php echo e($a_cientifico->persona_realizo_analisis); ?>" style="width:500px; text-align:center;" ></td>
                            </tr>
                            <tr>
                                <td><label for="forma_obtencion_muestra" class="input-group-addon">Forma de obtencion de las muestras</label></td>
                                <td><input type="text" class="form-control"  name="forma_obtencion_muestra" value="<?php echo e($a_cientifico->forma_obtencion_muestra); ?>" style="width:500px; text-align:center;" ></td>
                            </tr>
                            <tr>
                                <td><label for="esquema" class="input-group-addon">Esquema</label></td>
                                <td><input type="file" class="form-control"  name="esquema" value="<?php echo e($a_cientifico->esquema); ?>" style="width:500px; text-align:center;" ></td>
                            </tr>
                            <tr>
                                <td><label for="indicaciones" class="input-group-addon">Indicaciones</label></td>
                                <td><input type="text" class="form-control"  name="indicaciones" value="<?php echo e($a_cientifico->indicaciones); ?>" style="width:500px; text-align:center;" ></td>
                            </tr>
                            <tr>
                                <td><label for="tipo_material" class="input-group-addon">Tipo de material</label></td>
                                <td><input type="text" class="form-control"  name="tipo_material" value="<?php echo e($a_cientifico->tipo_material); ?>" style="width:500px; text-align:center;" ></td>
                            </tr>
                            <tr>
                                <td><label for="descripcion" class="input-group-addon">Descripcion</label></td>
                                <td><input type="text" class="form-control"  name="descripcion" value="<?php echo e($a_cientifico->descripcion); ?>" style="width:500px; text-align:center;" ></td>
                            </tr>
                            <tr>
                                <td><label for="microfotografia" class="input-group-addon">Microfotografia</label></td>
                                <td><input type="file" class="form-control"  name="microfotografia" value="<?php echo e($a_cientifico->microfotografia); ?>" style="width:500px; text-align:center;" ></td>
                            </tr>
                            <tr>
                                <td><label for="info_definir" class="input-group-addon">Informacion por definir</label></td>
                                <td><input type="text" class="form-control"  name="info_definir" value="<?php echo e($a_cientifico->info_definir); ?>" style="width:500px; text-align:center;" ></td>
                            </tr>
                            <tr>
                                <th colspan="2" style="text-align:center; background-color: #7C858C; color:white;"><h3>Datos Analíticos</h3></th>
                            </tr>
                            <tr>
                                <td><label for="analisis_microestructural" class="input-group-addon">Analisis Morfológico</label></td>
                                <td><input type="text" class="form-control"  name="analisis_morfologico" value="<?php echo e($a_cientifico->analisis_morfologico); ?>" style="width:500px; text-align:center;" ></td>
                            </tr>
                            <tr>
                                <td><label for="analisis_microquimico" class="input-group-addon">Analisis microquimico</label></td>
                                <td><input type="text" class="form-control"  name="analisis_microquimico" value="<?php echo e($a_cientifico->analisis_microquimico); ?>" style="width:500px; text-align:center;" ></td>
                            </tr>
                            <tr>
                                <td><label for="analisis_elemental" class="input-group-addon">Analisis microelemental</label></td>
                                <td><input type="text" class="form-control"  name="analisis_elemental" value="<?php echo e($a_cientifico->analisis_elemental); ?>" style="width:500px; text-align:center;" ></td>
                            </tr>
                            <tr>
                                <td><label for="analisis_molecular" class="input-group-addon">Analisis molecular</label></td>
                                <td><input type="text" class="form-control"  name="analisis_molecular" value="<?php echo e($a_cientifico->analisis_molecular); ?>" style="width:500px; text-align:center;" ></td>
                            </tr>
                            <tr>
                                <td><label for="analisis_de_tincion" class="input-group-addon">Analisis de tincion</label></td>
                                <td><input type="text" class="form-control"  name="analisis_de_tincion" value="<?php echo e($a_cientifico->analisis_de_tincion); ?>" style="width:500px; text-align:center;" ></td>
                            </tr>
                            <tr>
                                <td><label for="analisis_microbiologicos" class="input-group-addon">Analisis Microbiológicos</label></td>
                                <td><input type="text" class="form-control"  name="analisis_microbiologicos" value="<?php echo e($a_cientifico->analisis_microbiologicos); ?>" style="width:500px; text-align:center;" ></td>
                            </tr>
                            <tr>
                                <td><label for="otros" class="input-group-addon">Otros</label></td>
                                <td><input type="text" class="form-control"  name="otros" value="<?php echo e($a_cientifico->otros); ?>" style="width:500px; text-align:center;" ></td>
                            </tr>
                            <tr>
                                <th colspan="2" style="text-align:center; background-color: #7C858C; color:white;"><h3>Resultados</h3></th>
                            </tr>
                            <tr>
                                <td><label for="resultado_conclucion_general" class="input-group-addon">Conclusión Generak</label></td>
                                <td><input type="text" class="form-control"  name="resultado_conclucion_general" value="<?php echo e($a_cientifico->resultado_conclucion_general); ?>" style="width:500px; text-align:center;" ></td>
                            </tr>
                            <tr>
                                <td><label for="interpretacion_particular" class="input-group-addon">Interpretación Particular</label></td>
                                <td><input type="text" class="form-control"  name="interpretacion_particular" value="<?php echo e($a_cientifico->interpretacion_particular); ?>" style="width:500px; text-align:center;" ></td>
                            </tr>
                        </table>
                    </div> 
                    <br><br>  
                    <div class="col-md-12 text-center">
                            <button type="submit" class="btn btn-primary btn-sm">Capturar</button>
                            <a href="<?php echo e(route('registro.index')); ?>" class="btn btn-danger btn-sm">Cancelar</a>
                    </div>
                </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>