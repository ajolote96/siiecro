 
<?php $__env->startSection('main-content'); ?>

<?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
<?php endif; ?>
<div class="box">
	<div class="box-body">
		<div class="panel">
			<h1>
			Registro de Análisis Científico
			<?php echo e(Form::open(['route' => 'registro.index', 'method' => 'GET', 'class' => 'form-inline pull-right'])); ?>

			<div class="form-group">
				<input  class="form-control" type="text" name="id_obra" placeholder="ID">
			</div>
			<div class="form-group">
				<button type="submit" class="btn btn-default">
					<span class="glyphicon glyphicon-search"></span>
				</button>
			</div>
			<?php echo e(Form::close()); ?>

			</h1>
		</div>
		<div style="overflow-x: auto; ">
			<div>
				<table id="tablaObras" class="table table-hover" role="grid" align="center">
					<thead >
        				<tr align="center" >
        					<th>Nomenclatura</th>
        					<th>Titulo de la Obra</th>
				            <th>Área</th>
				            <th>Caracterización de Tipo de Análisis</th>
				            <th>Interpretación Particular</th>
				            <th>Foto</th>
            				<th>Acción</th>
        				</tr>
       				</thead>
       				<tbody>
       					<?php $__currentLoopData = $a_cientifico; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cienti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       					<tr align="center">
       						<td><?php echo e($cienti->nomenclatura_muestra); ?></td>
				            <td><?php echo e($cienti->titulo_obra); ?></td>
				            <td></td>
				            <td><?php echo e($cienti->caracte_analisis); ?></td>
				            <td><?php echo e($cienti->interpretacion_particular); ?></td>
				            
                            <?php if($cienti->esquema == 'Sin imagen'): ?>
                            <td>Sin imagen</td>
                            <?php else: ?>
                            <td><a target="_blank" href="<?php echo e("images/$cienti->esquema"); ?>"><img  width="200px" src="images/<?php echo e($cienti->esquema); ?>" class="zoom"></a></td>
                            <?php endif; ?>
				            <td>
				            	<td><a href="<?php echo e(route('registro.show', $cienti->idcientifico)); ?>" class="btn btn-block btn-info btn-xs" style="width:70px;">Ver mas</a></td>
				            	
				            	<td><a href="<?php echo e(route('registro.editar', $cienti->idcientifico)); ?>" class="btn btn-block btn-warning btn-xs" style="width:70px;">Editar</a></td>
				            	<td><a href="javascript: document.getElementById('delete-<?php echo e($cienti->idcientifico); ?>').submit()" class="btn btn-block btn-danger btn-xs" onclick="return confirm('¿Seguro que deseas eliminarlo?')" style="width:70px;">Eliminar</a></td>
				            	
				            	<form id="delete-<?php echo e($cienti->idcientifico); ?>" action="<?php echo e(route('registro.destroy', $cienti->idcientifico)); ?>" method="POST">
		                    	<?php echo method_field('delete'); ?>
		 						<?php echo csrf_field(); ?>
                			</form>
            				</td>
        				</tr>
          				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    				</tbody>
    			</table>
                <div align="center">
                	<?php echo $a_cientifico->links(); ?>  
                </div>
			</div>
		</div>				 	
  	</div>
</div>
<script src="../../bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>