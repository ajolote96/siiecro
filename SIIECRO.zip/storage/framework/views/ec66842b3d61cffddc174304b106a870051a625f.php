
<h1>Emisor del correo:</h1> <br>
<?php echo e($datos); ?>


<h2>Nombre(s):</h2>
<?php echo e($nombres); ?>


<h3>contenido del correo:</h3> <br>
<?php echo e($msg); ?>


