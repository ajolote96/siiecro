 
<?php $__env->startSection('main-content'); ?>

<?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
<?php endif; ?>



<div class="box">
	<div class="box-body">
		<div class="panel">
			<h1>
			Obras Registradas
			<?php echo e(Form::open(['route' => 'Obras.index', 'method' => 'GET', 'class' => 'form-inline pull-right'])); ?>

			<div class="form-group">
				<?php echo e(Form::text('id', null, ['class' => 'form-control', 'placeholder' => 'ID'])); ?>

			</div>
			<div class="form-group">
				<button type="submit" class="btn btn-default">
					<span class="glyphicon glyphicon-search"></span>
				</button>
				
			</div>

			<?php echo e(Form::close()); ?>

			</h1>
		</div>

		<div style="overflow-x: auto; ">
			<div>
				<table id="tablaObras" class="table table-hover" role="grid" align="center">
					<thead >
        				<tr align="center" >
        					<th>id</th>
        					<th>Obra</th>
				            <th>Caracteristicas Descriptivas</th>
				            <th>año</th>
				            <th>año confirmamdo</th>
				            <th>Año Aproximado</th>
				            <th>Epoca de la Obra</th>
				            <th>Epoca Confirmada</th>
				            <th>Epoca Aproximada</th>
							<th>Temporalidad</th>
				            <th>Tipo de bien cultural</th>
				            <th>Tipo de Objeto de la Obra</th>
				            <th>Sector de la obra</th>
				            <th>Proyecto de la Obra</th>
				            <th>Año de proyecto</th>
							<th>Temporada de trabajo</th>
            				<th>Acción</th>
        				</tr>
       				</thead>
       				<tbody>
       					<?php $__currentLoopData = $Obras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Obra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       					<tr align="center">
       						<td><?php echo e($Obra->id); ?></td>
				            <td><?php echo e($Obra->titulo_obra); ?></td>
				            <td><?php echo e($Obra->caract_descrip); ?></td>
				            <td><?php echo e($Obra->año); ?></td>
				            <td><?php echo e($Obra->año_confirm); ?></td>
				            <td><?php echo e($Obra->año_aproxi); ?></td>
				            <td><?php echo e($Obra->epoca_obra); ?></td>
				            <td><?php echo e($Obra->epoca_confirm); ?></td>
				            <td><?php echo e($Obra->epoca_aproxi); ?></td>
							<td><?php echo e($Obra->temp_obra); ?></td>
				            <td><?php echo e($Obra->tipo_bien_cultu); ?></td>
				            <td><?php echo e($Obra->tipo_obj_obra); ?></td>
				            <td><?php echo e($Obra->sector_obra); ?></td>
				            <td><?php echo e($Obra->proyecto_obra); ?></td>
				            <td><?php echo e($Obra->año_proyec_obra); ?></td>
							<td><?php echo e($Obra->temporada_trabajo); ?></td>
				            <td>
				            <a href="<?php echo e(route('Obras.show', $Obra->id)); ?>" class="btn btn-block btn-info btn-xs" style="width:70px;">Ver mas</a>
		                    <a href="<?php echo e(route('Obras.editar', $Obra->id)); ?>" class="btn btn-block btn-warning btn-xs" style="width:70px;">Editar</a>
		                    <a href="javascript: document.getElementById('delete-<?php echo e($Obra->id); ?>').submit()" class="btn btn-block btn-danger btn-xs" onclick="return confirm('¿Seguro que deseas eliminarlo?')" style="width:70px;">Eliminar</a>
		                    <?php if (\Entrust::can('AgregarF')) : ?>
		                    <a href="<?php echo e(route('analisisg.create', $Obra->id)); ?>" class="btn btn-block btn-success btn-xs" >Agregar ficha</a>
		                    <?php endif; // Entrust::can ?>
		                    <form id="delete-<?php echo e($Obra->id); ?>" action="<?php echo e(route('Obras.destroy', $Obra->id)); ?>" method="POST">
		                    	<?php echo method_field('delete'); ?>
		 						<?php echo csrf_field(); ?>
                   

                			</form>
  							
            				</td>
        				</tr>
          				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    				</tbody>
       					
    			</table>
                <div align="center">
                <?php echo $Obras->links(); ?>  
                </div>
  
		</div>
	</div>				 	
  </div>
</div>
   
<script src="../../bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>

      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>