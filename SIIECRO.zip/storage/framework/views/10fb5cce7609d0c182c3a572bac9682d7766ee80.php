	
 
<?php $__env->startSection('main-content'); ?>

<?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
<?php endif; ?>
<div class="box">
	<div class="box-body">
		<div class="panel">
			<h1>
			Solicitud de Análisis Científico
			<?php echo e(Form::open(['route' => 'analisisg.index', 'method' => 'GET', 'class' => 'form-inline pull-right'])); ?>

			<div class="form-group">
				<input  class="form-control" type="text" name="id_obra" placeholder="ID">
			</div>
			<div class="form-group">
				<button type="submit" class="btn btn-default">
					<span class="glyphicon glyphicon-search"></span>
				</button>
			</div>
			<?php echo e(Form::close()); ?>

			</h1>
		</div>
		<div style="overflow-x: auto; ">
			<div>
				<table id="tablaObras" class="table table-hover" role="grid" align="center">
					<thead >
        				<tr align="center" >
        					<th>ID Obra</th>
        					<th>Titulo de la Obra</th>
        					<th>Año</th>
        					<th>Epoca de la Obra</th>
				            <th>Temporalidad</th>
				            <th>Sector</th>
				            <th>responsable de la Intervencion</th>
				            <th>Año de temporada de trabajo</th>
                            <th>Foto</th>
            				<th>Acción</th>
        				</tr>
       				</thead>
       				<tbody>
       					<?php $__currentLoopData = $Analisisg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $analisg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       					<tr align="center">
       						<td><?php echo e($analisg->id_de_obra); ?></td>
				            <td><?php echo e($analisg->titulo_obra); ?></td>
				            <td><?php echo e($analisg->año); ?></td>
				            <td><?php echo e($analisg->epoca_obra); ?></td>
				            <td><?php echo e($analisg->temp_obra); ?></td>
				            <td><?php echo e($analisg->sector_obra); ?></td>
				            <td><?php echo e($analisg->respon_intervencion); ?></td>
				            <td><?php echo e($analisg->anio_temporada_trabajo); ?></td>
                           
                            <?php if($analisg->foto == 'Sin imagen'): ?>
                            <td>Sin imagen</td>
                            <?php else: ?>
                            <td><a target="_blank" href="<?php echo e("images/$analisg->foto"); ?>"><img  width="200px" src="images/<?php echo e($analisg->foto); ?>" class="zoom"></a></td>
                            <?php endif; ?>
				            <td>
				            	<td><a href="<?php echo e(route('analisisg.show', $analisg->id_general)); ?>" class="btn btn-block btn-info btn-xs" style="width:70px;">Ver mas</a></td>
				            	
				            	<td><a href="<?php echo e(route('analisisg.editar', $analisg->id_general)); ?>" class="btn btn-block btn-warning btn-xs" style="width:70px;">Editar</a>
				            		
				            	</td>
				            	
				            	
				            	<td><form id="delete-<?php echo e($analisg->id_general); ?>" action="<?php echo e(route('analisisg.destroy', $analisg->id_general)); ?>" method="POST">
				            			<a href="javascript:document.getElementById('delete-<?php echo e($analisg->id_general); ?>').submit()" class="btn btn-block btn-danger btn-xs" onclick="return confirm('¿Seguro que deseas eliminarlo?')" style="width:70px;">Eliminar</a>
		                    	<?php echo method_field('delete'); ?>
		 						<?php echo csrf_field(); ?>
                			</form></td>
				            	
				            	<td><a href="<?php echo e(route('registro.create', $analisg->id_general)); ?>" class="btn btn-block btn-success btn-xs" >Agregar registro</a></td>

								<td><a target="_blank" href="<?php echo e(route('analisisgeneral.pdf', $analisg->id_general)); ?>" class="btn btn-block btn-success btn-xs" style="width:90px;">Imprimir</a></td>
				            	
				            	<form id="delete-<?php echo e($analisg->id_general); ?>" action="<?php echo e(route('analisisg.destroy', $analisg->id_general)); ?>" method="POST">
		                    	<?php echo method_field('delete'); ?>
		 						<?php echo csrf_field(); ?>
                			</form>
            				</td>
        				</tr>
          				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    				</tbody>
    			</table>
                <div align="center">
                	<?php echo $Analisisg->links(); ?>  
                </div>
			</div>
		</div>				 	
  	</div>
</div>
<script src="../../bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>