<style> p.saltodepagina
 {
 page-break-after: always;
 }
 </style>
 <img  align="left" width="200px" src="images/Logotipo_ECRO_Gris.png" >
<div class="box">
    <div class="box-body"  >
    
            <div class="panel" >
             <h1 style=" text-align:center;">Solicitud de Análisis Científico</h1>
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <strong>Vaya!</strong> Algo salio mal.<br><br>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
                <form action="<?php echo e(route('analisisg.actualizar', $analisisg->id_general)); ?>" method="POST" class="form-inline text-left" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?> 

                    <div  align="center" >
                        <table "width: 100%" border="0" align="center" cellspacing="4" cellpadding="4">
                            <tr>
                                <th colspan="4" style="text-align:center; background-color: #7C858C; color:white; font-size:30px; " ><h3>Datos Generales</h3></th>
                            </tr>
                           
                            <tr >
                               <td> <label for="id_de_obra" class="input-group-addon" style="width: 300px; font-size:20px; border:0;">ID Obra </label></td>
                               <td style=" font-size:20px; text-align:center;">  <?php echo e($analisisg->id_de_obra); ?> </td>    
                            </tr>
                            <tr >
                               <td> <label for="titulo_obra" class="input-group-addon" style="width: 300px; font-size:20px; border:0;">Titulo de la obra/pieza</label></td>
                               <td style=" font-size:20px; text-align:center;"><?php echo e($analisisg->titulo_obra); ?></td>
                            </tr>
							<tr>
                               <td> <span class="input-group-addon"style="width: 300px; font-size:20px; border:0;">Temporalidad</span></td>
                               <td style=" font-size:20px; text-align:center;"><?php echo e($analisisg->temp_obra); ?></td>
                            </tr>
                            <?php if($analisisg->epoca_obra == NULL): ?>
                            <?php else: ?>
                            <tr>
                              <td>  <label for="epoca_obra" class="input-group-addon"style="width: 300px; font-size:20px; border:0;">Epoca de la obra</label></td>
                              <td style=" font-size:20px; text-align:center;"><?php echo e($analisisg->epoca_obra); ?></td>
                            </tr>
                            <?php endif; ?>
                            <tr>
                              <td>  <label for="tipo_obj_obra" class="input-group-addon"style="width: 300px; font-size:20px; border:0;">Tipo de objeto de la obra</label></td>
                               <td style=" font-size:20px; text-align:center;"><?php echo e($analisisg->tipo_obj_obra); ?></td>
                            </tr>
                            <tr>
                            <td><label for="anio_temporada_trabajo" class="input-group-addon" style="width: 300px; font-size:20px;">Año de temporada de trabajo</label></td>
                            <td style=" font-size:20px; text-align:center;"><?php echo e($analisisg->anio_temporada_trabajo); ?></td>
                        </tr>
                        <?php if($analisisg->año_de_obra == NULL): ?>
                        <?php else: ?>
                        <tr>
                            <td><label for="año_de_obra" class="input-group-addon" style="width: 300px; font-size:20px;">Año de la Obra</label></td>
                            <td style=" font-size:20px; text-align:center;"><?php echo e($analisisg->año_de_obra); ?></td>
                        </tr>
                        <?php endif; ?>
                       <tr>
                        <td><label for="respon_intervencion" class="input-group-addon"style="width: 300px; font-size:20px; border:0;">Responsable de la Intervencion</label></td>
                        <td style=" font-size:20px; text-align:center;"><?php echo e($analisisg->respon_intervencion); ?></td>
                      </tr>
                     <tr>
                       <td> <label for="tecnica" class="input-group-addon"style="width: 300px; font-size:20px; border:0;">Tecnica</label></td>
                        <td style=" font-size:20px; text-align:center;"><?php echo e($analisisg->tecnica); ?>"</td>
                     </tr>
                     <tr>
                     <td> <label for="tecnica" class="input-group-addon"style="width: 300px; font-size:20px; border:0;">Fecha de entrada</label></td>
                           <td style=" font-size:20px; text-align:center;"><?php echo e($analisisg->fecha_de_inicio); ?></td>
                        </tr>
                 </table>
             </div>
             <!-- -->
                <div align="left"  style="padding-left:-13%">
                    <table "width: 100%" border="0" align="center" cellspacing="4" cellpadding="4">
                        <tr>
                            <th></th>
                            <th style="text-align:center; background-color: #7C858C; color:white;">Alto</th>
                            <th style="text-align:center; background-color: #7C858C; color:white;">Ancho</th>
                            <th style="text-align:center; background-color: #7C858C; color:white;">Profundidad</th>
                            <th style="text-align:center; background-color: #7C858C; color:white;">Diametro</th>
                        </tr>
                        <tr>
                            <th style="font-size:30px;">Dimensiones </th>
                            <td><input type="text" class="form-control" name="alto" value="<?php echo e($analisisg->alto); ?>" style="width:143px; text-align:center; "></td></td>
                            <td><input type="text" class="form-control" name="ancho" value="<?php echo e($analisisg->ancho); ?>"style="width:143px; text-align:center; "></td></td>
                            <td><input type="text" class="form-control" name="profundidad" value="<?php echo e($analisisg->profundidad); ?>"style="width:143px; text-align:center; "></td>
                            <td><input type="text" class="form-control" name="diametro" value="<?php echo e($analisisg->diametro); ?>"style="width:143px; text-align:center; "></td>
                        </tr>
                    </table>

</div>  <!--aca termina-->
<br>
                <div  align="center" style="padding-left:0%">
                    <table style="width: 44%" class="table-bordered" align="center">
                        <tr>
                            <th style="text-align: center; background-color: #7C858C; color:white;">Foto de inicio</th>
                            <th style="text-align: center; background-color: #7C858C; color:white;">Esquema de toma de muestra</th>
                    </tr>
                    <tr>
                        <td align="center">
                            <?php if($analisisg->foto == 'Sin imagen'): ?>
                        <input type="text" class="form-control"  name="foto" border="0" value="Sin imagen" style="width:200px">
                        <?php else: ?>
                        <img  width="400px" src="images/<?php echo e($analisisg->foto); ?>" class="">
                        <?php endif; ?>  
                        </td>
                        <td align="center">
                            <?php if($analisisg->esquema_muestras == 'Sin imagen'): ?>
                        <input type="text" class="form-control"  name="esquema_muestras" border="0" value="Sin imagen" style="width:200px">
                        <?php else: ?>
                        <img  width="400px" src="images/<?php echo e($analisisg->esquema_muestras); ?>" class="">
                        <?php endif; ?>
                        </td>
                        
                    </tr>
                    </table>  
                    </div>
                    <h2 style="background-color: #7C858C; color:white; text-align:center; ">Analisis</h2>
               <!--TABLA SOPORTE  I-->
                <?php $__currentLoopData = $soportes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $soporte): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="input-group" id="tabso"  style=" text-align:left;" >
                <label><strong>I. SOPORTE</strong> </label>
                    <table class="table table-bordered" style="width: 50%"> 
                        <thead>
                            <tr align="center">
                                <th style="background-color: #C65911; color:white; ">Número de muestra</th>
                                <th style="background-color: #C65911; color:white; ">Nomenclatura</th>
                                <th style="background-color: #C65911; color:white; ">Información requerida</th>
                                <th style="background-color: #C65911; color:white; ">Descripcion de la muestra</th>
                                <th style="background-color: #C65911; color:white; ">Ubicación</th>
                                <th style="background-color: #C65911; color:white; ">Responsable</th>
                                <th style="background-color: #C65911; color:white; ">No. de indentificacion</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr align="center">
                                <td><input type="text" name="Smuestra" value="<?php echo e($soporte->soporte_muestra); ?>"></td>
                                <td><input type="text" name="Snomenclatura" value="<?php echo e($soporte->soporte_nomenclatura); ?>"></td>
                                <td><input type="text" name="Sinf_requerida" value="<?php echo e($soporte->soporte_inf_requerida); ?>"></td>
                                <td><input type="text" name="Sdes_muestra" value="<?php echo e($soporte->soporte_des_muestra); ?>"></td>
                                <td><input type="text" name="Subicacion" value="<?php echo e($soporte->soporte_ubicacion); ?>"></td>
                                <td><input type="text" name="Sresponsable" value="<?php echo e($soporte->soporte_responsable); ?>"></td>
                                <td><input type="text" name="Siden_muestra" value="<?php echo e($soporte->soporte_identificacion_muestra); ?>"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <!--TABLA BASE MUESTRA II -->
               <?php $__currentLoopData = $baseP; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bases): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div class="input-group" id="tabbase"  style=" text-align:left;">
               <label><strong>II. BASE DE PREPARACIÓN</strong> </label>
                    <table class="table table-bordered" style="width: 50%">
                        <thead>
                            <tr align="center">
                                <th style="background-color: #FFCC66; color:white; ">Nomenclatura</th>
                                <th style="background-color: #FFCC66; color:white; ">Número de muestra</th>
                                <th style="background-color: #FFCC66; color:white; ">Información requerida</th>
                                <th style="background-color: #FFCC66; color:white; ">Descripcion de la muestra</th>
                                <th style="background-color: #FFCC66; color:white; ">Ubicación</th>
                                <th style="background-color: #FFCC66; color:white; ">Responsable</th>
                                <th style="background-color: #FFCC66; color:white; ">No. de indentificacion</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr align="center">
                                <td><input type="text" name="BPmuestra" value="<?php echo e($bases->base_muestra); ?>"></td>
                                <td><input type="text" name="BPnomenclatura" value="<?php echo e($bases->base_nomenclatura); ?>"></td>
                                <td><input type="text" name="BPinf_requerida" value="<?php echo e($bases->base_inf_requerida); ?>"></td>
                                <td><input type="text" name="BPdes_muestra" value="<?php echo e($bases->base_des_muestra); ?>"></td>
                                <td><input type="text" name="BPubicacion" value="<?php echo e($bases->base_ubicacion); ?>"></td>
                                <td><input type="text" name="BPresponsable" value="<?php echo e($bases->base_responsable); ?>"></td>
                                <td><input type="text" name="BPiden_muestra" value="<?php echo e($bases->base_identificacion_muestra); ?>"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <!--ESTATIGRAFIA-->
                
                <?php $__currentLoopData = $estratigrafia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estratigrafias): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="input-group" id="tabbase"  style=" text-align:left;">
                <label><strong>III. ESTRATIGRAFÍA</strong> </label>
                    <table class="table table-bordered" style="width: 50%">
                        <thead>
                            <tr align="center">
                                <th style="background-color: #008000; color:white;">Número de muestra</th>
                                <th style="background-color: #008000; color:white;">Nomenclatura</th>
                                <th style="background-color: #008000; color:white;">Información requerida</th>
                                <th style="background-color: #008000; color:white;">Descripcion de la muestra</th>
                                <th style="background-color: #008000; color:white;">Ubicación</th>
                                <th style="background-color: #008000; color:white;">Responsable</th>
                                <th style="background-color: #008000; color:white;">No. de indentificacion</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr align="center">
                                <td><input type="text" name="Emuestra" value="<?php echo e($estratigrafias->estratigrafia_muestra); ?>"></td>
                                <td><input type="text" name="Enomenclatura" value="<?php echo e($estratigrafias->estratigrafia_nomenclatura); ?>"></td>
                                <td><input type="text" name="Einf_requerida" value="<?php echo e($estratigrafias->estratigrafia_inf_requerida); ?>"></td>
                                <td><input type="text" name="Edes_muestra" value="<?php echo e($estratigrafias->estratigrafia_des_muestra); ?>"></td>
                                <td><input type="text" name="Eubicacion" value="<?php echo e($estratigrafias->estratigrafia_ubicacion); ?>"></td>
                                <td><input type="text" name="Eresponsable" value="<?php echo e($estratigrafias->estratigrafia_responsable); ?>"></td>
                                <td><input type="text" name="Eiden_muestra" value="<?php echo e($estratigrafias->estratigrafia_identificacion_muestra); ?>"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

                <!--REVOQUE Y ENLUCIDO-->
                <?php $__currentLoopData = $revoque; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $revoques): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div class="input-group" id="tabbase" style=" text-align:left;">
               <label><strong>IV. REVOQUE Y ENLUCIDO</strong> </label>
                    <table class="table table-bordered" style="width: 50%">
                        <thead>
                            <tr align="center">
                                <th style="background-color: #B248A5; color:white;">Número de muestra</th>
                                <th style="background-color: #B248A5; color:white;">Nomenclatura</th>
                                <th style="background-color: #B248A5; color:white;">Información requerida</th>
                                <th style="background-color: #B248A5; color:white;">Descripcion de la muestra</th>
                                <th style="background-color: #B248A5; color:white;">Ubicación</th>
                                <th style="background-color: #B248A5; color:white;">Responsable</th>
                                <th style="background-color: #B248A5; color:white;">No. de indentificacion</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr align="center">
                                <td><input type="text" name="REmuestra" value="<?php echo e($revoques->revoque_muestra); ?>"></td>
                                <td><input type="text" name="REnomenclatura" value="<?php echo e($revoques->revoque_nomenclatura); ?>"></td>
                                <td><input type="text" name="REinf_requerida" value="<?php echo e($revoques->revoque_inf_requerida); ?>"></td>
                                <td><input type="text" name="REdes_muestra" value="<?php echo e($revoques->revoque_des_muestra); ?>"></td>
                                <td><input type="text" name="REubicacion" value="<?php echo e($revoques->revoque_ubicacion); ?>"></td>
                                <td><input type="text" name="REresponsable" value="<?php echo e($revoques->revoque_responsable); ?>"></td>
                                <td><input type="text" name="REiden_muestra" value="<?php echo e($revoques->revoque_identificacion_muestra); ?>"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                 

                <!--BOL-->
                <?php $__currentLoopData = $bol; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bols): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div class="input-group" id="tabbol" style=" text-align:left;">
               <label><strong>VI. BOL</strong> </label>
                    <table class="table table-bordered" style="width: 50%">
                    
                        <thead>
                            <tr align="center">
                                <th style="background-color: #FF5050; color:white;">Número de muestra</th>
                                <th style="background-color: #FF5050; color:white;">Nomenclatura</th>
                                <th style="background-color: #FF5050; color:white;">Información requerida</th>
                                <th style="background-color: #FF5050; color:white;">Descripcion de la muestra</th>
                                <th style="background-color: #FF5050; color:white;">Ubicación</th>
                                <th style="background-color: #FF5050; color:white;">Responsable</th>
                                <th style="background-color: #FF5050; color:white;">No. de indentificacion</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr align="center">
                                <td><input type="text" name="BOLmuestra" value="<?php echo e($bols->bol_muestra); ?>"></td>
                                <td><input type="text" name="BOLnomenclatura" value="<?php echo e($bols->bol_nomenclatura); ?>"></td>
                                <td><input type="text" name="BOLinf_requerida" value="<?php echo e($bols->bol_inf_requerida); ?>"></td>
                                <td><input type="text" name="BOLdes_muestra" value="<?php echo e($bols->bol_des_muestra); ?>"></td>
                                <td><input type="text" name="BOLubicacion" value="<?php echo e($bols->bol_ubicacion); ?>"></td>
                                <td><input type="text" name="BOLresponsable" value="<?php echo e($bols->bol_responsable); ?>"></td>
                                <td><input type="text" name="BOLiden_muestra" value="<?php echo e($bols->bol_identificacion_muestra); ?>"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    

                <!--LAMINAS METALICAS -->
                 <?php $__currentLoopData = $lamina; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $laminas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div class="input-group" id="tabbol" style=" text-align:left;" >
               <label><strong>VII. LÁMINAS METÁLICAS</strong> </label>
                    <table class="table table-bordered" style="width: 50%">

                        <thead>
                            <tr align="center">
                                <th style="background-color: #3A5754; color:white;">Número de muestra</th>
                                <th style="background-color: #3A5754; color:white;">Nomenclatura</th>
                                <th style="background-color: #3A5754; color:white;">Información requerida</th>
                                <th style="background-color: #3A5754; color:white;">Descripcion de la muestra</th>
                                <th style="background-color: #3A5754; color:white;">Ubicación</th>
                                <th style="background-color: #3A5754; color:white;">Responsable</th>
                                <th style="background-color: #3A5754; color:white;">No. de indentificacion</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr align="center">
                                <td><input type="text" name="LMmuestra" value="<?php echo e($laminas->laminas_muestra); ?>"></td>
                                <td><input type="text" name="LMnomenclatura" value="<?php echo e($laminas->laminas_nomenclatura); ?>"></td>
                                <td><input type="text" name="LMinf_requerida" value="<?php echo e($laminas->laminas_inf_requerida); ?>"></td>
                                <td><input type="text" name="LMdes_muestra" value="<?php echo e($laminas->laminas_des_muestra); ?>"></td>
                                <td><input type="text" name="LMubicacion" value="<?php echo e($laminas->laminas_ubicacion); ?>"></td>
                                <td><input type="text" name="LMresponsable" value="<?php echo e($laminas->laminas_responsable); ?>"></td>
                                <td><input type="text" name="LMiden_muestra" value="<?php echo e($laminas->laminas_identificacion_muestra); ?>"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    

                <!-- PIGMENTOS -->
                <?php $__currentLoopData = $pigmento; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pigmentos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div class="input-group" id="tabbol" style=" text-align:left;" >
               <label><strong>VIII.PIGMENTOS</strong></label>
                    <table class="table table-bordered" style="width: 50%"> 
                        <thead>
                            <tr align="center">
                                <th style="background-color: #5B9BD5; color:white;">Número de muestra</th>
                                <th style="background-color: #5B9BD5; color:white;">Nomenclatura</th>
                                <th style="background-color: #5B9BD5; color:white;">Información requerida</th>
                                <th style="background-color: #5B9BD5; color:white;">Descripcion de la muestra</th>
                                <th style="background-color: #5B9BD5; color:white;">Ubicación</th>
                                <th style="background-color: #5B9BD5; color:white;">Responsable</th>
                                <th style="background-color: #5B9BD5; color:white;">No. de indentificacion</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr align="center">
                                <td><input type="text" name="LMmuestra" value="<?php echo e($pigmentos->pigmentos_muestra); ?>"></td>
                                <td><input type="text" name="LMnomenclatura" value="<?php echo e($pigmentos->pigmentos_nomenclatura); ?>"></td>
                                <td><input type="text" name="LMinf_requerida" value="<?php echo e($pigmentos->pigmentos_inf_requerida); ?>"></td>
                                <td><input type="text" name="LMdes_muestra" value="<?php echo e($pigmentos->pigmentos_des_muestra); ?>"></td>
                                <td><input type="text" name="LMubicacion" value="<?php echo e($pigmentos->pigmentos_ubicacion); ?>"></td>
                                <td><input type="text" name="LMresponsable" value="<?php echo e($pigmentos->pigmentos_responsable); ?>"></td>
                                <td><input type="text" name="LMiden_muestra" value="<?php echo e($pigmentos->pigmentos_identificacion_muestra); ?>"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <!-- AGLUTINANTES -->
                <?php $__currentLoopData = $aglutinante; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aglutinantes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div class="input-group" id="tabbol" style=" text-align:left;">
               <label><strong>IX.AGLUTINANTES</strong></label>
                    <table class="table table-bordered" style="width: 50%">
                        <thead>
                            <tr align="center">
                                <th style="background-color: #F55587; color:white;">Número de muestra</th>
                                <th style="background-color: #F55587; color:white;">Nomenclatura</th>
                                <th style="background-color: #F55587; color:white;">Información requerida</th>
                                <th style="background-color: #F55587; color:white;">Descripcion de la muestra</th>
                                <th style="background-color: #F55587; color:white;">Ubicación</th>
                                <th style="background-color: #F55587; color:white;">Responsable</th>
                                <th style="background-color: #F55587; color:white;">No. de indentificacion</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr align="center">
                                <td><input type="text" name="Amuestra" value="<?php echo e($aglutinantes->aglutinante_muestra); ?>"></td>
                                <td><input type="text" name="Anomenclatura" value="<?php echo e($aglutinantes->aglutinante_nomenclatura); ?>"></td>
                                <td><input type="text" name="Ainf_requerida" value="<?php echo e($aglutinantes->aglutinante_inf_requerida); ?>"></td>
                                <td><input type="text" name="Ades_muestra" value="<?php echo e($aglutinantes->aglutinante_des_muestra); ?>"></td>
                                <td><input type="text" name="Aubicacion" value="<?php echo e($aglutinantes->aglutinante_ubicacion); ?>"></td>
                                <td><input type="text" name="Aresponsable" value="<?php echo e($aglutinantes->aglutinante_responsable); ?>"></td>
                                <td><input type="text" name="Aiden_muestra" value="<?php echo e($aglutinantes->aglutinante_identificacion_muestra); ?>"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>             

                <!-- RECUBRIMIENTOS -->
                <?php $__currentLoopData = $recubrimiento; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recubrimientos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div class="input-group" id="tabbol" style=" text-align:left;">
               <label><strong>X. RECUBRIMIENTOS</strong></label>
                    <table class="table table-bordered" style="width: 50%"> 
                        <thead>
                            <tr align="center">
                                <th style="background-color: #FBAE47; color:white;">Número de muestra</th>
                                <th style="background-color: #FBAE47; color:white;">Nomenclatura</th>
                                <th style="background-color: #FBAE47; color:white;">Información requerida</th>
                                <th style="background-color: #FBAE47; color:white;">Descripcion de la muestra</th>
                                <th style="background-color: #FBAE47; color:white;">Ubicación</th>
                                <th style="background-color: #FBAE47; color:white;">Responsable</th>
                                <th style="background-color: #FBAE47; color:white;">No. de indentificacion</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr align="center">
                                <td><input type="text" name="Rmuestra" value="<?php echo e($recubrimientos->recubrimiento_muestra); ?>"></td>
                                <td><input type="text" name="Rnomenclatura" value="<?php echo e($recubrimientos->recubrimiento_nomenclatura); ?>"></td>
                                <td><input type="text" name="Rinf_requerida" value="<?php echo e($recubrimientos->recubrimiento_inf_requerida); ?>"></td>
                                <td><input type="text" name="Rdes_muestra" value="<?php echo e($recubrimientos->recubrimiento_des_muestra); ?>"></td>
                                <td><input type="text" name="Rubicacion" value="<?php echo e($recubrimientos->recubrimiento_ubicacion); ?>"></td>
                                <td><input type="text" name="Rresponsable" value="<?php echo e($recubrimientos->recubrimiento_responsable); ?>"></td>
                                <td><input type="text" name="Riden_muestra" value="<?php echo e($recubrimientos->recubrimiento_identificacion_muestra); ?>"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                

                <!--MATERIAL ASOCIADO XI -->
                <?php $__currentLoopData = $maso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materialaso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div class="input-group" id="tabmaterialaso" style=" text-align:left;">
               <label><strong>XI. MATERIAL ASOCIADO </strong></label>
                    <table class="table table-bordered" style="width: 50%"> 
                        <thead>
                            <tr align="center">
                                <th style="background-color: #009999; color:white;">Nomenclatura</th>
                                <th style="background-color: #009999; color:white;">Número de muestra</th>
                                <th style="background-color: #009999; color:white;">Información requerida</th>
                                <th style="background-color: #009999; color:white;">Descripcion de la muestra</th>
                                <th style="background-color: #009999; color:white;">Ubicación</th>
                                <th style="background-color: #009999; color:white;">Responsable</th>
                                <th style="background-color: #009999; color:white;">No. de indentificacion</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr align="center">
                                <td><input type="text" name="MASOmuestra" value="<?php echo e($materialaso->materialaso_muestra); ?>"></td>
                                <td><input type="text" name="MASOnomenclatura" value="<?php echo e($materialaso->materialaso_nomenclatura); ?>"></td>
                                <td><input type="text" name="MASOinf_requerida" value="<?php echo e($materialaso->materialaso_inf_requerida); ?>"></td>
                                <td><input type="text" name="MASOdes_muestra" value="<?php echo e($materialaso->materialaso_des_muestra); ?>"></td>
                                <td><input type="text" name="MASOubicacion" value="<?php echo e($materialaso->materialaso_ubicacion); ?>"></td>
                                <td><input type="text" name="MASOresponsable" value="<?php echo e($materialaso->materialaso_responsable); ?>"></td>
                                <td><input type="text" name="MASOiden_muestra" value="<?php echo e($materialaso->materialaso_identificacion_muestra); ?>"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                <!--SALES XII -->
                <?php $__currentLoopData = $sal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sales): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div class="input-group" id="tabsales" style=" text-align:left;" >
               <label><strong>XII. SALES </strong></label>
                    <table class="table table-bordered" style="width: 50%"> 
                        <thead>
                            <tr align="center">
                                <th style="background-color: #009999; color:white;">Nomenclatura</th>
                                <th style="background-color: #009999; color:white;">Número de muestra</th>
                                <th style="background-color: #009999; color:white;">Información requerida</th>
                                <th style="background-color: #009999; color:white;">Descripcion de la muestra</th>
                                <th style="background-color: #009999; color:white;">Ubicación</th>
                                <th style="background-color: #009999; color:white;">Responsable</th>
                                <th style="background-color: #009999; color:white;">No. de indentificacion</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr align="center">
                                <td><input type="text" name="SALmuestra" value="<?php echo e($sales->sales_muestra); ?>"></td>
                                <td><input type="text" name="SALnomenclatura" value="<?php echo e($sales->sales_nomenclatura); ?>"></td>
                                <td><input type="text" name="SALinf_requerida" value="<?php echo e($sales->sales_inf_requerida); ?>"></td>
                                <td><input type="text" name="SALdes_muestra" value="<?php echo e($sales->sales_des_muestra); ?>"></td>
                                <td><input type="text" name="SALubicacion" value="<?php echo e($sales->sales_ubicacion); ?>"></td>
                                <td><input type="text" name="SALresponsable" value="<?php echo e($sales->sales_responsable); ?>"></td>
                                <td><input type="text" name="SALiden_muestra" value="<?php echo e($sales->sales_identificacion_muestra); ?>"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                
                <!--MATERIAL AGREGADO XIII -->
                <?php $__currentLoopData = $materialag; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div class="input-group" id="tabmaterialag"  style=" text-align:left;">
               <label><strong>XIII. MATERIAL AGREGADO </strong> </label>
                    <table class="table table-bordered" style="width: 50%">
                        <thead>
                            <tr align="center">
                                <th style="background-color: #7D10C0; color:white;">Nomenclatura</th>
                                <th style="background-color: #7D10C0; color:white;">Número de muestra</th>
                                <th style="background-color: #7D10C0; color:white;">Información requerida</th>
                                <th style="background-color: #7D10C0; color:white;">Descripcion de la muestra</th>
                                <th style="background-color: #7D10C0; color:white;">Ubicación</th>
                                <th style="background-color: #7D10C0; color:white;">Responsable</th>
                                <th style="background-color: #7D10C0; color:white;">No. de indentificacion</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr align="center">
                                <td><input type="text" name="MAGmuestra" value="<?php echo e($matag->materialag_muestra); ?>"></td>
                                <td><input type="text" name="MAGnomenclatura" value="<?php echo e($matag->materialag_nomenclatura); ?>"></td>
                                <td><input type="text" name="MAGinf_requerida" value="<?php echo e($matag->materialag_inf_requerida); ?>"></td>
                                <td><input type="text" name="MAGdes_muestra" value="<?php echo e($matag->materialag_des_muestra); ?>"></td>
                                <td><input type="text" name="MAGubicacion" value="<?php echo e($matag->materialag_ubicacion); ?>"></td>
                                <td><input type="text" name="MAGresponsable" value="<?php echo e($matag->materialag_responsable); ?>"></td>
                                <td><input type="text" name="MAGiden_muestra" value="<?php echo e($matag->materialag_identificacion_muestra); ?>"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                <!--TABLA BIODETERIORO XIV -->
                <?php $__currentLoopData = $biodeterioro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $biodeterioros): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div class="input-group" id="tabbiodeterioro"  style=" text-align:left;">
               <label><strong>XIV. BIODETERIORO </strong></label>
                    <table class="table table-bordered" style="width: 50%"> 
                        <thead>
                            <tr align="center">
                                <th style="background-color: #A2C866; color:white;">Nomenclatura</th>
                                <th style="background-color: #A2C866; color:white;">Número de muestra</th>
                                <th style="background-color: #A2C866; color:white;">Información requerida</th>
                                <th style="background-color: #A2C866; color:white;">Descripcion de la muestra</th>
                                <th style="background-color: #A2C866; color:white;">Ubicación</th>
                                <th style="background-color: #A2C866; color:white;">Responsable</th>
                                <th style="background-color: #A2C866; color:white;">No. de indentificacion</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr align="center">
                                <td><input type="text" name="BDTmuestra" value="<?php echo e($biodeterioros->biodeterioro_muestra); ?>"></td>
                                <td><input type="text" name="BDTnomenclatura" value="<?php echo e($biodeterioros->biodeterioro_nomenclatura); ?>"></td>
                                <td><input type="text" name="BDTinf_requerida" value="<?php echo e($biodeterioros->biodeterioro_inf_requerida); ?>"></td>
                                <td><input type="text" name="BDTdes_muestra" value="<?php echo e($biodeterioros->biodeterioro_des_muestra); ?>"></td>
                                <td><input type="text" name="BDTubicacion" value="<?php echo e($biodeterioros->biodeterioro_ubicacion); ?>"></td>
                                <td><input type="text" name="BDTresponsable" value="<?php echo e($biodeterioros->biodeterioro_responsable); ?>"></td>
                                <td><input type="text" name="BDTiden_muestra" value="<?php echo e($biodeterioros->biodeterioro_identificacion_muestra); ?>"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





                <!--TABLA OTROS XV -->
                <?php $__currentLoopData = $otros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $otro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div class="input-group" id="tabbase"  style=" text-align:left;">
               <label><strong>XV. OTROS</strong></label>
                    <table class="table table-bordered" style="width: 50%"> 
                        <thead>
                            <tr align="center">
                                <th style="background-color: #A5A5A5; color:white;" >Número de muestra</th>
                                <th style="background-color: #A5A5A5; color:white;" >Nomenclatura</th>
                                <th style="background-color: #A5A5A5; color:white;" >Información requerida</th>
                                <th style="background-color: #A5A5A5; color:white;" >Descripcion de la muestra</th>
                                <th style="background-color: #A5A5A5; color:white;" >Ubicación</th>
                                <th style="background-color: #A5A5A5; color:white;" >Responsable</th>
                                <th style="background-color: #A5A5A5; color:white;" >No. de indentificacion</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr align="center">
                                <td><input type="text" name="OTmuestra" value="<?php echo e($otro->otros_muestra); ?>"></td>
                                <td><input type="text" name="OTnomenclatura" value="<?php echo e($otro->otros_nomenclatura); ?>"></td>
                                <td><input type="text" name="OTinf_requerida" value="<?php echo e($otro->otros_inf_requerida); ?>"></td>
                                <td><input type="text" name="OTdes_muestra" value="<?php echo e($otro->otros_des_muestra); ?>"></td>
                                <td><input type="text" name="OTubicacion" value="<?php echo e($otro->otros_ubicacion); ?>"></td>
                                <td><input type="text" name="OTresponsable" value="<?php echo e($otro->otros_responsable); ?>"></td>
                                <td><input type="text" name="OTiden_muestra" value="<?php echo e($otro->otros_identificacion_muestra); ?>"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <br><br>
                  
                </form>
        </div>
	</div>
</div