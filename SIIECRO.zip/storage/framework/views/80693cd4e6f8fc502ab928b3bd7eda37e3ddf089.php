<?php
$con = new mysqli("localhost","root","","siecrodb");
$sql ="select id , titulo_obra from obras";
$res = $con->query($sql);
?>


<?php $__env->startSection('htmlheader_title'); ?>
	<?php echo e(trans('adminlte_lang::message.home')); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('main-content'); ?>
	<div class="container-fluid spark-screen">
		<div class="row">
			<div class="col-md-8 col-md-offset-2">
				<div class="panel panel-default">
					<div class="panel-heading">Inicio</div>

					<div class="panel-body">
						<strong> Bienvenido <?php echo e(Auth::user()->name); ?></strong>
            <br><br>
						 	<div class="box box-danger">
            <div class="box-header with-border">
              <h3 class="box-title">Grafica Pastel</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <div class="Chart">
              <html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
       
     var data = google.visualization.arrayToDataTable([
          ['ID', 'Titulo de obra'],
          <?php
          while($file = $res->fetch_assoc()){
            echo "['".$file["titulo_obra"]."',".$file["id"]."],";
          }
  ?>
     ]);
        var options = {
          title: 'Obras del dia'
        };

        var chart = new google.visualization.PieChart(document.getElementById('donutchart'));
        chart.draw(data, options);
      }
    </script>
  </head>
  <body>
    <div id="donutchart" style="width: 900px; height: 500px;"></div>
  </body>
</html>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
						 
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>