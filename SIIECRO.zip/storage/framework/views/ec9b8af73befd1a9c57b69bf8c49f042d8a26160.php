 <script src="js/jquery-3.2.1.js"></script>
    <script src="js/scrpt.jis"></script>
<?php $__env->startSection('main-content'); ?>
<div class="box">
    <div class="box-body"  >
            <div class="panel">

<style>
.invalid-feedback{
display:block;
}
</style>


   <section class="form_wrap" >

        <section class="cantact_info">
            <section class="info_title">
                <img  style="padding-left: 80px;" src="images/logo_usuario.png" width="180px"  />
                <h2>INFORMACION<br>DE CONTACTO</h2>
            </section>
            <section class="info_items">
                <p><span class="fa fa-envelope"></span> jose.bcarranza@academicos.udg.mx</p>

         

            <?php if(Session::has('flash_message')): ?>
            <div class="alert alert-success">
                <?php echo e(Session::get('flash_message')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php endif; ?>
            </section>
            </section>

        <form method="post" action="<?php echo e(route('contact.store')); ?>" class="form_contact">
            <h2 style="text-align: center;">Envia un mensaje</h2>
            <?php echo e(csrf_field()); ?>


                 
                <label for="names">Nombres *</label>
                <input type="text" id="name" name="name" value="<?php echo e(Auth::user()->name); ?>" class="form-control"required>
                <?php if($errors->has('name')): ?>
            <small class="form-text invalid-feedback"><?php echo e($errors->first('name')); ?></small>
            <?php endif; ?>
  
                <label for="email">Correo electronico *</label>
                <input type="text" class="form-control" id="email" name="email" value="<?php echo e(Auth::user()->email); ?>" required>
                <?php if($errors->has('email')): ?>
            <small class="form-text invalid-feedback"><?php echo e($errors->first('email')); ?></small>
            <?php endif; ?>
  
                <label for="mensaje">Mensaje *</label>
                <textarea id="mensaje" class="form-control"  name="message"required></textarea>
                   <?php if($errors->has('message')): ?>
            <small class="form-text invalid-feedback"><?php echo e($errors->first('message')); ?></small>
            <?php endif; ?>

           <input type="submit" value="Enviar Mensaje" id="btnSend">
            </div>
        </form>



    </section>

</div>

</div>
</div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>