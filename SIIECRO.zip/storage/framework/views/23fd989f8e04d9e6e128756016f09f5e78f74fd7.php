<!-- Main Footer -->
<footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
        <a href="l"></a><b>SIIECRO</b></a>
    </div>
    <!-- Default to the left -->
    <strong>Sistema Integral de Informacion de la Escuela de Conservasion y Restauracion de Occidente </strong>
</footer>