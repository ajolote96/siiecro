 
<?php $__env->startSection('main-content'); ?>

<!--<?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div><?php echo e($Obrasg->first()->id); ?>

<?php endif; ?>-->
<div class="box">
    <div class="box-body"  >
            <div class="panel">
                <h1>Editar Solicitud de Análisis Científico 
			
</h1>
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <strong>Vaya!</strong> Algo salio mal.<br><br>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
                <form action="<?php echo e(route('analisisg.actualizar', $analisisg->id_general)); ?>" method="POST" class="form-inline text-left" enctype="multipart/form-data">
                    <?php echo method_field('put'); ?>
                    <?php echo csrf_field(); ?> 

                    <BR>
                    <div class="form-group">
                        <div class="form-group">
                            
                            <div class="input-group" >
                                <label for="id_obra" class="input-group-addon">ID Obra </label>
                                <input type="text" name="id_obra" class="form-control"  value="<?php echo e($analisisg->id_obra); ?>" style="width:200px" readonly><BR>    
                            </div>
                            <div class="input-group" >
                                <label for="titulo_obra" class="input-group-addon">Titulo de la obra/pieza</label>
                                <input type="text" name="titulo_obra" class="form-control"  value="<?php echo e($analisisg->titulo_obra); ?>" style="width:200px" readonly><BR> 
                            </div>
							<div class="form-group">
							<div class="input-group">
                                <span class="input-group-addon">Temporalidad</span>
                                <input type="text" name="temp_obra" class="form-control"  value="<?php echo e($analisisg->temp_obra); ?>" style="width:200px" readonly>
                            </div>
                        	</div><br><br>
                        
                            <div class="input-group ">
                                <label for="epoca_obra" class="input-group-addon">Epoca de la obra</label>
                                <input type="text" name="epoca_obra" class="form-control"  value="<?php echo e($analisisg->epoca_obra); ?>" style="width:200px" readonly>
                            </div>
                            <div class="input-group ">
                                <label for="tipo_bien_cultu" class="input-group-addon">Tipo de bien cultural</label>
                                <input type="text" name="tipo_bien_cultu" class="form-control"  value="<?php echo e($analisisg->tipo_bien_cultu); ?>" style="width:200px" readonly>
                            </div>
                            <div class="input-group">
                                <label for="tipo_obj_obra" class="input-group-addon">Tipo de objeto de la obra</label>
                                <input type="text" name="tipo_obj_obra" class="form-control"  value="<?php echo e($analisisg->tipo_obj_obra); ?>" style="width:200px" readonly>
                            </div>
                        </div><br><br>
                        <div class="form-group">                            
                            <div class="input-group">
                                <label for="lugar_proce_ori" class="input-group-addon">Lugar de procedencia original</label>
                                <input type="text" class="form-control"  name="lugar_proce_ori"  value="<?php echo e($analisisg->lugar_proce_ori); ?>" style="width:200px"readonly>
                            </div>
                            <div class="input-group">
                                <label for="lugar_proce_act" class="input-group-addon">Lugar de procedencia actual</label>
                                <input type="text" class="form-control"  name="lugar_proce_act"  value="<?php echo e($analisisg->lugar_proce_act); ?>" style="width:200px" readonly>
                            </div>
                            <div class="input-group">
                        	<label for="no_inv_obra" class="input-group-addon">Numero de inventario de la obra</label>
                        	<input type="text" class="form-control"  name="no_inv_obra"  value="<?php echo e($analisisg->no_inv_obra); ?>" style="width:200px" readonly>
                    	</div>
                        </div><br><br>
                        
                    	<div class="form-group">
                    
                    <div class="input-group">
                        <label for="proyecto_obra" class="input-group-addon">Proyecto de la obra</label>
                        <input type="text" class="form-control"  name="proyecto_obra"  value="<?php echo e($analisisg->proyecto_obra); ?>" style="width:200px" readonly>
                    </div>
                    <div class="input-group">
                        <label for="año_proyec_obra" class="input-group-addon">Año de proyecto de la obra</label>
                        <input type="text" class="form-control"  name="año_proyec_obra" value="<?php echo e($analisisg->año_proyec_obra); ?>" style="width:200px" readonly>
                    </div>
                    <div class="input-group">
                        <label for="respon_intervencion" class="input-group-addon">Responsable de la Intervencion</label>
                        <input type="text" class="form-control"  name="respon_intervencion"  value="<?php echo e($analisisg->respon_intervencion); ?>" style="width:200px">
                    </div>
                    
                </div><br><br>
                      <div class="input-group">
                        <label for="foto" class="input-group-addon">Foto</label>
                        <input type="file" class="form-control"  name="foto" value="<?php echo e($analisisg->foto); ?>" >
                    </div>
                
                    <div class="input-group">
                    <div class="input-group date">

                        <div class="input-group-addon">
                             <i class="fa fa-calendar"> Fecha de entrada</i>

                        </div>

                        <input type="date" class="form-control date" name="fecha_de_inicio" placeholder="mm/dd/aaaa (Fecha de entrada)" value="<?php echo e($analisisg->fecha_de_inicio); ?>" style="width:262px">
                    </div>
                
                    
                    </div>
                    </div><br><br>
                    <div class="form-group">
                    
                    <div class="input-group">
                        <label for="tecnica" class="input-group-addon">Tecnica</label>
                        <input type="text" class="form-control"  name="tecnica" value="<?php echo e($analisisg->tecnica); ?>" style="width:200px">
                    </div>
                    <div class="input-group">
                        <label for="autor" class="input-group-addon">Autor</label>
                        <input type="text" class="form-control"  name="autor" value="<?php echo e($analisisg->autor); ?>" style="width:200px">
                    </div><br><br>
                    <div class="col-md-12"></div>

                    <div class="input-group">
                        <div class="input-group">
                            <label class="input-group-addon">Dimensiones</label>
                            <label class="input-group-addon">Alto</label>
                            <input type="text" class="form-control" name="alto" value="<?php echo e($analisisg->alto); ?>"><br>
                            <label class="input-group-addon">Ancho</label>
                            <input type="text" class="form-control" name="ancho" value="<?php echo e($analisisg->ancho); ?>"><br>
                            <label class="input-group-addon">Profundidad</label>
                            <input type="text" class="form-control" name="profundidad" value="<?php echo e($analisisg->profundidad); ?>"><br>
                            <label class="input-group-addon">Diametro</label>
                            <input type="text" class="form-control" name="diametro" value="<?php echo e($analisisg->diametro); ?>"><br>
                        </div>
                        
                    </div><br><br>
                    
                    
                </div><br><br>
                <!--<table class="table table-bordered"><b>ANALISIS</b><br>
                    <thead>
                        <tr>
                            <th><label><input type="checkbox" name="tsoporte" id="tsoporte" onchange="javascript:showSoporte()"> SOPORTE</label><br></th>
                            <th><label><input type="checkbox" name="tbase" id="tbase" onchange="javascript:showBase()"> BASE DE PREPAPRACION</label><br></th>
                            <th><label><input type="checkbox" name="testra" id="testra" onchange="javascript:showEstra()"> ESTRATIGRAFIA</label></th>
                            <th><label><input type="checkbox" name="trevo" id="trevo" onchange="javascript:showRevo()"> REVOQUE Y ELUCIDO</label></th>
                            <th><label><input type="checkbox" name="tbol" id="tbol" onchange="javascript:showBol()"> BOL</label></th>
                            <th><label><input type="checkbox" name="tlame" id="tlami" onchange="javascript:showLami()"> LAMINAS METALICAS</label></th>
                            <th><label><input type="checkbox" name="tpig" id="tpig" onchange="javascript:showPig()"> PIGMENTOS</label></th>
                            
                            
                            
                        </tr>
                    </thead>
                    <tbody>
                            <tr>
                                <td><label><input type="checkbox" name="taglu" id="taglu" onchange="javascript:showAglu()"> AGLUTINANTE</label></td>
                                <td><label><input type="checkbox" name="trecu" id="trecu" onchange="javascript:showRecu()"> RECUBRIMIENTO</label></td>
                                <td><label><input type="checkbox" name="tmaso" id="tmaso" onchange="javascript:showMaso()"> MATERIAL ASOCIADO</label></td>
                                <td><label><input type="checkbox" name="tsal" id="tsal" onchange="javascript:showSal()"> SALES</label></td>
                                <td><label><input type="checkbox" name="tmagre" id="tmagre" onchange="javascript:showMagre()"> MATERIAL AGREGADO</label></td>
                                <td><label><input type="checkbox" name="tbio" id="tbio" onchange="javascript:showBio()"> BIODETERIORO</label></td>
                                <td><label><input type="checkbox" name="totro" id="totro" onchange="javascript:showOtro()"> OTROS</label></td>
                                </tr>
                        </tbody>
                </table>
                <br><br>   -->   
                <?php if($analisisg->Smuestra != null): ?>          
                <div class="input-group" id="tabso" >
                    <table class="table table-bordered" background-color: red;><strong>SOPORTE</strong> 
                        <thead>
                            <tr align="center">
                                <th bgcolor="">Número de muestra</th>
                                <th>Nomenclatura</th>
                                <th>Información requerida</th>
                                <th>Descripcion de la muestra</th>
                                <th>Ubicación</th>
                                <th>Motivo</th>
                                <th>Responsable</th>
                                <th>No. de indentificacion</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr align="center">
                                <td><input type="text" name="Smuestra" value="<?php echo e($analisisg->Smuestra); ?>"></td>
                                <td><input type="text" name="Snomenclatura" value="<?php echo e($analisisg->Snomenclatura); ?>"></td>
                                <td><input type="text" name="Sinf_requerida" value="<?php echo e($analisisg->Sinf_requerida); ?>"></td>
                                <td><input type="text" name="Sdes_muestra" value="<?php echo e($analisisg->Sdes_muestra); ?>"></td>
                                <td><input type="text" name="Subicacion" value="<?php echo e($analisisg->Subicacion); ?>"></td>
                                <td><input type="text" name="Smotivo" value="<?php echo e($analisisg->Smotivo); ?>"></td>
                                <td><input type="text" name="Sresponsable" value="<?php echo e($analisisg->Sresponsable); ?>"></td>
                                <td><input type="text" name="Siden_muestra" value="<?php echo e($analisisg->Siden_muestra); ?>"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
                <?php if($analisisg->BPmuestra != null): ?>
                <div class="input-group" id="tabbase" >
                    <table class="table table-bordered"><strong>BASE DE PREPARACION</strong> 
                        <thead>
                            <tr align="center">
                                <th>Número de muestra</th>
                                <th>Nomenclatura</th>
                                <th>Información requerida</th>
                                <th>Descripcion de la muestra</th>
                                <th>Ubicación</th>
                                <th>Motivo</th>
                                <th>Responsable</th>
                                <th>No. de indentificacion</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr align="center">
                                <td><input type="text" name="BPmuestra" value="<?php echo e($analisisg->BPmuestra); ?>"></td>
                                <td><input type="text" name="BPnomenclatura" value="<?php echo e($analisisg->BPnomenclatura); ?>"></td>
                                <td><input type="text" name="BPinf_requerida" value="<?php echo e($analisisg->BPinf_requerida); ?>"></td>
                                <td><input type="text" name="BPdes_muestra" value="<?php echo e($analisisg->BPdes_muestra); ?>"></td>
                                <td><input type="text" name="BPubicacion" value="<?php echo e($analisisg->BPubicacion); ?>"></td>
                                <td><input type="text" name="BPmotivo" value="<?php echo e($analisisg->BPmotivo); ?>"></td>
                                <td><input type="text" name="BPresponsable" value="<?php echo e($analisisg->BPresponsable); ?>"></td>
                                <td><input type="text" name="BPiden_muestra" value="<?php echo e($analisisg->BPiden_muestra); ?>"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
                <?php if($analisisg->Emuestra != null): ?>
                <div class="input-group" id="tabestra" >
                    <table class="table table-bordered"><strong>ESTRATIGRAFIA</strong> 
                        <thead>
                            <tr align="center">
                                <th>Número de muestra</th>
                                <th>Nomenclatura</th>
                                <th>Información requerida</th>
                                <th>Descripcion de la muestra</th>
                                <th>Ubicación</th>
                                <th>Motivo</th>
                                <th>Responsable</th>
                                <th>No. de indentificacion</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr align="center">
                                <td><input type="text" name="Emuestra" value="<?php echo e($analisisg->Emuestra); ?>"></td>
                                <td><input type="text" name="Enomenclatura" value="<?php echo e($analisisg->Enomenclatura); ?>"></td>
                                <td><input type="text" name="Einf_requerida" value="<?php echo e($analisisg->Einf_requerida); ?>"></td>
                                <td><input type="text" name="Edes_muestra" value="<?php echo e($analisisg->Edes_muestra); ?>"></td>
                                <td><input type="text" name="Eubicacion" value="<?php echo e($analisisg->Eubicacion); ?>"></td>
                                <td><input type="text" name="Emotivo" value="<?php echo e($analisisg->Emotivo); ?>"></td>
                                <td><input type="text" name="Eresponsable" value="<?php echo e($analisisg->Eresponsable); ?>"></td>
                                <td><input type="text" name="Eiden_muestra" value="<?php echo e($analisisg->Eiden_muestra); ?>"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                 <?php endif; ?>
                <?php if($analisisg->REmuestra != null): ?>
                <div class="input-group" id="tabrevo" >
                    <table class="table table-bordered"><strong>REVOQUE Y ENLUCIDO</strong> 
                        <thead>
                            <tr align="center">
                                <th>Número de muestra</th>
                                <th>Nomenclatura</th>
                                <th>Información requerida</th>
                                <th>Descripcion de la muestra</th>
                                <th>Ubicación</th>
                                <th>Motivo</th>
                                <th>Responsable</th>
                                <th>No. de indentificacion</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr align="center">
                                <td><input type="text" name="REmuestra" value="<?php echo e($analisisg->REmuestra); ?>"></td>
                                <td><input type="text" name="REnomenclatura" value="<?php echo e($analisisg->REmuestra); ?>"></td>
                                <td><input type="text" name="REinf_requerida" value="<?php echo e($analisisg->REinf_requerida); ?>"></td>
                                <td><input type="text" name="REdes_muestra" value="<?php echo e($analisisg->REdes_muestra); ?>"></td>
                                <td><input type="text" name="REubicacion" value="<?php echo e($analisisg->REubicacion); ?>"></td>
                                <td><input type="text" name="REmotivo" value="<?php echo e($analisisg->REmotivo); ?>"></td>
                                <td><input type="text" name="REresponsable" value="<?php echo e($analisisg->REresponsable); ?>"></td>
                                <td><input type="text" name="REiden_muestra" value="<?php echo e($analisisg->REiden_muestra); ?>"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                 <?php endif; ?>
                <?php if($analisisg->BOLmuestra != null): ?>
                <div class="input-group" id="tabbol" >
                    <table class="table table-bordered"><strong>BOL</strong> 
                        <thead>
                            <tr align="center">
                                <th>Número de muestra</th>
                                <th>Nomenclatura</th>
                                <th>Información requerida</th>
                                <th>Descripcion de la muestra</th>
                                <th>Ubicación</th>
                                <th>Motivo</th>
                                <th>Responsable</th>
                                <th>No. de indentificacion</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr align="center">
                                <td><input type="text" name="BOLmuestra" value="<?php echo e($analisisg->BOLmuestra); ?>"></td>
                                <td><input type="text" name="BOLnomenclatura" value="<?php echo e($analisisg->BOLnomenclatura); ?>"></td>
                                <td><input type="text" name="BOLinf_requerida" value="<?php echo e($analisisg->BOLinf_requerida); ?>"></td>
                                <td><input type="text" name="BOLdes_muestra" value="<?php echo e($analisisg->BOLdes_muestra); ?>"></td>
                                <td><input type="text" name="BOLubicacion" value="<?php echo e($analisisg->BOLubicacion); ?>"></td>
                                <td><input type="text" name="BOLmotivo" value="<?php echo e($analisisg->BOLmotivo); ?>"></td>
                                <td><input type="text" name="BOLresponsable" value="<?php echo e($analisisg->BOLresponsable); ?>"></td>
                                <td><input type="text" name="BOLiden_muestra" value="<?php echo e($analisisg->BOLiden_muestra); ?>"></td>
                            </tr>
                        </tbody>
                    </table>
                </div> 
                <?php endif; ?>
                <?php if($analisisg->LMmuestra != null): ?>
                <div class="input-group" id="tablami" >
                    <table class="table table-bordered"><strong>LAMINAS METALICAS</strong> 
                        <thead>
                            <tr align="center">
                                <th>Número de muestra</th>
                                <th>Nomenclatura</th>
                                <th>Información requerida</th>
                                <th>Descripcion de la muestra</th>
                                <th>Ubicación</th>
                                <th>Motivo</th>
                                <th>Responsable</th>
                                <th>No. de indentificacion</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr align="center">
                                <td><input type="text" name="LMmuestra" value="<?php echo e($analisisg->LMmuestra); ?>"></td>
                                <td><input type="text" name="LMnomenclatura" value="<?php echo e($analisisg->LMnomenclatura); ?>"></td>
                                <td><input type="text" name="LMinf_requerida" value="<?php echo e($analisisg->LMinf_requerida); ?>"></td>
                                <td><input type="text" name="LMdes_muestra" value="<?php echo e($analisisg->LMdes_muestra); ?>"></td>
                                <td><input type="text" name="LMubicacion" value="<?php echo e($analisisg->LMubicacion); ?>"></td>
                                <td><input type="text" name="LMmotivo" value="<?php echo e($analisisg->LMmotivo); ?>"></td>
                                <td><input type="text" name="LMresponsable" value="<?php echo e($analisisg->LMresponsable); ?>"></td>
                                <td><input type="text" name="LMiden_muestra" value="<?php echo e($analisisg->LMiden_muestra); ?>"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                 <?php endif; ?>
                <?php if($analisisg->Pmuestra != null): ?>
                <div class="input-group" id="tabpig" >
                    <table class="table table-bordered"><strong>PIGMENTOS</strong> 
                        <thead>
                            <tr align="center">
                                <th>Número de muestra</th>
                                <th>Nomenclatura</th>
                                <th>Información requerida</th>
                                <th>Descripcion de la muestra</th>
                                <th>Ubicación</th>
                                <th>Motivo</th>
                                <th>Responsable</th>
                                <th>No. de indentificacion</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr align="center">
                                <td><input type="text" name="Pmuestra" value="<?php echo e($analisisg->Pmuestra); ?>"></td>
                                <td><input type="text" name="Pnomenclatura" value="<?php echo e($analisisg->Pnomenclatura); ?>"></td>
                                <td><input type="text" name="Pinf_requerida" value="<?php echo e($analisisg->Pinf_requerida); ?>"></td>
                                <td><input type="text" name="Pdes_muestra" value="<?php echo e($analisisg->Pdes_muestra); ?>"></td>
                                <td><input type="text" name="Pubicacion" value="<?php echo e($analisisg->Pubicacion); ?>"></td>
                                <td><input type="text" name="Pmotivo" value="<?php echo e($analisisg->Pmotivo); ?>"></td>
                                <td><input type="text" name="Presponsable" value="<?php echo e($analisisg->Presponsable); ?>"></td>
                                <td><input type="text" name="Piden_muestra" value="<?php echo e($analisisg->Piden_muestra); ?>"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                 <?php endif; ?>
                <?php if($analisisg->Ämuestra != null): ?>
                <div class="input-group" id="tabaglu">
                    <table class="table table-bordered"><strong>AGLUTINANTE</strong> 
                        <thead>
                            <tr align="center">
                                <th>Número de muestra</th>
                                <th>Nomenclatura</th>
                                <th>Información requerida</th>
                                <th>Descripcion de la muestra</th>
                                <th>Ubicación</th>
                                <th>Motivo</th>
                                <th>Responsable</th>
                                <th>No. de indentificacion</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr align="center">
                                <td><input type="text" name="Amuestra" value="<?php echo e($analisisg->Amuestra); ?>"></td>
                                <td><input type="text" name="Anomenclatura" value="<?php echo e($analisisg->Anomenclatura); ?>"></td>
                                <td><input type="text" name="Ainf_requerida" value="<?php echo e($analisisg->Ainf_requerida); ?>"></td>
                                <td><input type="text" name="Ades_muestra" value="<?php echo e($analisisg->Ades_muestra); ?>"></td>
                                <td><input type="text" name="Aubicacion" value="<?php echo e($analisisg->Aubicacion); ?>"></td>
                                <td><input type="text" name="Amotivo" value="<?php echo e($analisisg->Amotivo); ?>"></td>
                                <td><input type="text" name="Aresponsable" value="<?php echo e($analisisg->Aresponsable); ?>"></td>
                                <td><input type="text" name="Aiden_muestra" value="<?php echo e($analisisg->Aiden_muestra); ?>"></td>
                            </tr>
                        </tbody>
                    </table>
                </div> 
                <?php endif; ?>
                <?php if($analisisg->Rmuestra != null): ?>
                <div class="input-group" id="tabrecu" >
                    <table class="table table-bordered"><strong>RECUBRIMIENTO</strong> 
                        <thead>
                            <tr align="center">
                                <th>Número de muestra</th>
                                <th>Nomenclatura</th>
                                <th>Información requerida</th>
                                <th>Descripcion de la muestra</th>
                                <th>Ubicación</th>
                                <th>Motivo</th>
                                <th>Responsable</th>
                                <th>No. de indentificacion</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr align="center">
                                <td><input type="text" name="Rmuestra" value="<?php echo e($analisisg->Rmuestra); ?>"></td>
                                <td><input type="text" name="Rnomenclatura" value="<?php echo e($analisisg->Rnomenclatura); ?>"></td>
                                <td><input type="text" name="Rinf_requerida" value="<?php echo e($analisisg->Rinf_requerida); ?>"></td>
                                <td><input type="text" name="Rdes_muestra" value="<?php echo e($analisisg->Rdes_muestra); ?>"></td>
                                <td><input type="text" name="Rubicacion" value="<?php echo e($analisisg->Rubicacion); ?>"></td>
                                <td><input type="text" name="Rmotivo" value="<?php echo e($analisisg->Rmotivo); ?>"></td>
                                <td><input type="text" name="Rresponsable" value="<?php echo e($analisisg->Rresponsable); ?>"></td>
                                <td><input type="text" name="Riden_muestra" value="<?php echo e($analisisg->Riden_muestra); ?>"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
                <?php if($analisisg->MASOmuestra != null): ?>
                <div class="input-group" id="tabmaso">
                    <table class="table table-bordered"><strong>MATERIAL ASOCIADO</strong> 
                        <thead>
                            <tr align="center">
                                <th>Número de muestra</th>
                                <th>Nomenclatura</th>
                                <th>Información requerida</th>
                                <th>Descripcion de la muestra</th>
                                <th>Ubicación</th>
                                <th>Motivo</th>
                                <th>Responsable</th>
                                <th>No. de indentificacion</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr align="center">
                                <td><input type="text" name="MASOmuestra" value="<?php echo e($analisisg->MASOmuestra); ?>"></td>
                                <td><input type="text" name="MASOnomenclatura" value="<?php echo e($analisisg->MASOnomenclatura); ?>"></td>
                                <td><input type="text" name="MASOinf_requerida" value="<?php echo e($analisisg->MASOinf_requerida); ?>"></td>
                                <td><input type="text" name="MASOdes_muestra" value="<?php echo e($analisisg->MASOdes_muestra); ?>"></td>
                                <td><input type="text" name="MASOubicacion" value="<?php echo e($analisisg->MASOubicacion); ?>"></td>
                                <td><input type="text" name="MASOmotivo" value="<?php echo e($analisisg->MASOmotivo); ?>"></td>
                                <td><input type="text" name="MASOresponsable" value="<?php echo e($analisisg->MASOresponsable); ?>"></td>
                                <td><input type="text" name="MASOiden_muestra" value="<?php echo e($analisisg->MASOiden_muestra); ?>"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
                <?php if($analisisg->SALmuestra != null): ?>
                <div class="input-group" id="tabsal">
                    <table class="table table-bordered"><strong>SAL</strong> 
                        <thead>
                            <tr align="center">
                                <th>Número de muestra</th>
                                <th>Nomenclatura</th>
                                <th>Información requerida</th>
                                <th>Descripcion de la muestra</th>
                                <th>Ubicación</th>
                                <th>Motivo</th>
                                <th>Responsable</th>
                                <th>No. de indentificacion</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr align="center">
                                <td><input type="text" name="SALmuestra" value="<?php echo e($analisisg->SALmuestra); ?>"></td>
                                <td><input type="text" name="SALnomenclatura" value="<?php echo e($analisisg->SALnomenclatura); ?>"></td>
                                <td><input type="text" name="SALinf_requerida" value="<?php echo e($analisisg->SALinf_requerida); ?>"></td>
                                <td><input type="text" name="SALdes_muestra" value="<?php echo e($analisisg->SALdes_muestra); ?>"></td>
                                <td><input type="text" name="SALubicacion" value="<?php echo e($analisisg->SALubicacion); ?>"></td>
                                <td><input type="text" name="SALmotivo" value="<?php echo e($analisisg->SALmotivo); ?>"></td>
                                <td><input type="text" name="SALresponsable" value="<?php echo e($analisisg->SALresponsable); ?>"></td>
                                <td><input type="text" name="SALiden_muestra" value="<?php echo e($analisisg->SALiden_muestra); ?>"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
                <?php if($analisisg->MAGREmuestra != null): ?>
                <div class="input-group" id="tabmagre" >
                    <table class="table table-bordered"><strong>MATERIAL AGREGADO</strong> 
                        <thead>
                            <tr align="center">
                                <th>Número de muestra</th>
                                <th>Nomenclatura</th>
                                <th>Información requerida</th>
                                <th>Descripcion de la muestra</th>
                                <th>Ubicación</th>
                                <th>Motivo</th>
                                <th>Responsable</th>
                                <th>No. de indentificacion</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr align="center">
                                <td><input type="text" name="MAGREmuestra" value="<?php echo e($analisisg->MAGREmuestra); ?>"></td>
                                <td><input type="text" name="MAGREnomenclatura" value="<?php echo e($analisisg->MAGREnomenclatura); ?>"></td>
                                <td><input type="text" name="MAGREinf_requerida" value="<?php echo e($analisisg->MAGREinf_requerida); ?>"></td>
                                <td><input type="text" name="MAGREdes_muestra" value="<?php echo e($analisisg->MAGREdes_muestra); ?>"></td>
                                <td><input type="text" name="MAGREubicacion" value="<?php echo e($analisisg->MAGREubicacion); ?>"></td>
                                <td><input type="text" name="MAGREmotivo" value="<?php echo e($analisisg->MAGREmotivo); ?>"></td>
                                <td><input type="text" name="MAGREresponsable" value="<?php echo e($analisisg->MAGREresponsable); ?>"></td>
                                <td><input type="text" name="MAGREiden_muestra" value="<?php echo e($analisisg->MAGREiden_muestra); ?>"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
                <?php if($analisisg->BIOmuestra != null): ?>
                <div class="input-group" id="tabbio">
                    <table class="table table-bordered"><strong>BIOTERIORO</strong> 
                        <thead>
                            <tr align="center">
                                <th>Número de muestra</th>
                                <th>Nomenclatura</th>
                                <th>Información requerida</th>
                                <th>Descripcion de la muestra</th>
                                <th>Ubicación</th>
                                <th>Motivo</th>
                                <th>Responsable</th>
                                <th>No. de indentificacion</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr align="center">
                                <td><input type="text" name="BIOmuestra" value="<?php echo e($analisisg->BIOmuestra); ?>"></td>
                                <td><input type="text" name="BIOnomenclatura" value="<?php echo e($analisisg->BIOnomenclatura); ?>"></td>
                                <td><input type="text" name="BIOinf_requerida" value="<?php echo e($analisisg->BIOinf_requerida); ?>"></td>
                                <td><input type="text" name="BIOdes_muestra" value="<?php echo e($analisisg->BIOdes_muestra); ?>"></td>
                                <td><input type="text" name="BIOubicacion" value="<?php echo e($analisisg->BIOubicacion); ?>"></td>
                                <td><input type="text" name="BIOmotivo" value="<?php echo e($analisisg->BIOmotivo); ?>"></td>
                                <td><input type="text" name="BIOresponsable" value="<?php echo e($analisisg->BIOresponsable); ?>"></td>
                                <td><input type="text" name="BIOiden_muestra" value="<?php echo e($analisisg->BIOiden_muestra); ?>"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
                <?php if($analisisg->OTROmuestra != null): ?>
                <div class="input-group" id="tabotro">
                    <table class="table table-bordered"><strong>OTROS</strong> 
                        <thead>
                            <tr align="center">
                                <th>Número de muestra</th>
                                <th>Nomenclatura</th>
                                <th>Información requerida</th>
                                <th>Descripcion de la muestra</th>
                                <th>Ubicación</th>
                                <th>Motivo</th>
                                <th>Responsable</th>
                                <th>No. de indentificacion</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr align="center">
                                <td><input type="text" name="OTROmuestra" value="<?php echo e($analisisg->OTROmuestra); ?>"></td>
                                <td><input type="text" name="OTROnomenclatura" value="<?php echo e($analisisg->OTROnomenclatura); ?>"></td>
                                <td><input type="text" name="OTROinf_requerida" value="<?php echo e($analisisg->OTROinf_requerida); ?>"></td>
                                <td><input type="text" name="OTROdes_muestra" value="<?php echo e($analisisg->OTROdes_muestra); ?>"></td>
                                <td><input type="text" name="OTROubicacion" value="<?php echo e($analisisg->OTROubicacion); ?>"></td>
                                <td><input type="text" name="OTROmotivo" value="<?php echo e($analisisg->OTROmotivo); ?>"></td>
                                <td><input type="text" name="OTROresponsable" value="<?php echo e($analisisg->OTROresponsable); ?>"></td>
                                <td><input type="text" name="OTROiden_muestra" value="<?php echo e($analisisg->OTROiden_muestra); ?>"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
                    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                            <button type="submit" class="btn btn-primary btn-sm">Guardar</button>
                            <a href="<?php echo e(route('analisisg.index')); ?>" class="btn btn-danger btn-sm">Cancelar</a>
                    </div>
                </form>
        </div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>