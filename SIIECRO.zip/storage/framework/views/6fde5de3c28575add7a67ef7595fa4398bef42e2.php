<style> p.saltodepagina
 {
 page-break-after: always;
 }
 </style>


<div class="box">
    <div class="box-body"  >
        <div class="panel">
        <img  width="200px" src="images/Logotipo_ECRO_Gris.png" >
            <h1 align="center">Datos de Registro de la Obra</h1>
<?php if($errors->any()): ?>
<br>
    <div class="alert alert-danger">
        <strong>Vaya!</strong> Parece que algo hiciste mal.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<form action="<?php echo e(route('Obras.actualizar', $obra->id)); ?>" method="POST" class="form-inline text-left">
    <?php echo csrf_field(); ?>
  
   
    <table style="width: 100%" border="0" align="center" cellspacing="4" cellpadding="4">
<tr ><th colspan="5"style="text-align:center;background-color: #7C858C; color:white;"><h3>Datos Generales</h3></th></tr>

<?php if (\Entrust::can(['Consulta_General_Basica','Consulta_General_Avanzada_2'])) : ?>
<?php if($obra->id_de_obras != NULL): ?>
  <tr>
    <td style="font-size:20px;">ID de Obra:</td>
    <td style="font-size:20px;"><?php echo e($obra->id_de_obras); ?></td>
  </tr><?php endif; ?>  <br><br><br><br>
<?php endif; // Entrust::can ?>
<?php if (\Entrust::can(['Consulta_General_Basica','Consulta_General_Avanzada_2','Consulta_Externa'])) : ?>
<tr>
  <td style="font-size:20px;">Titulo de la Obra:</td>
    <td style="font-size:20px;"><?php echo e($obra->titulo_obra); ?></td>
</tr>
<?php if($obra->autor != NULL): ?>
<tr>
  <td style="font-size:20px;">Autor:</td>
  <td style="font-size:20px;"><?php echo e($obra->autor); ?></td>
</tr>
<?php endif; ?>
<?php if($obra->cultura != NULL): ?>
<tr>
  <td style="font-size:20px;">Cultura:</td>
  <td style="font-size:20px;"><?php echo e($obra->cultura); ?></td>
</tr>
<?php endif; ?>
<tr>
  <td style="font-size:20px;">Tipo de Bien Cultural:</td>
  <td style="font-size:20px;"><?php echo e($obra->tipo_bien_cultu); ?></td>
</tr>

<tr>
  <td style="font-size:20px;">Tipo de Objeto de la Obra:</td>
  <td style="font-size:20px;"><?php echo e($obra->tipo_obj_obra); ?></td>
</tr>
<?php endif; // Entrust::can ?>
<?php if (\Entrust::can(['Consulta_General_Basica','Consulta_General_Avanzada_2'])) : ?>
<tr>
  <td style="font-size:20px;">Lugar de Procedencia Actual:</td>
  <td style="font-size:20px;"><?php echo e($obra->lugar_proce_act); ?></td>
</tr>
<?php endif; // Entrust::can ?>
<?php if (\Entrust::can('Consulta_General_Avanzada_2')) : ?>
<tr>
  <td style="font-size:20px;">Lugar de Procedencia Original:</td>
  <td style="font-size:20px;"><?php echo e($obra->lugar_proce_ori); ?></td>
</tr>
<tr>
    <td style="font-size:20px;">No. de inventario de la Obra o Códigos de Procedencia:</td>
    <td style="font-size:20px;"><?php echo e($obra->no_inv_obra); ?></td>
  </tr>
  <?php endif; // Entrust::can ?>
<?php if (\Entrust::can(['Consulta_General_Basica','Consulta_General_Avanzada_2'])) : ?>
<tr>
  <td style="font-size:20px;">Características Descriptivas:</td>
  <td style="font-size:20px;"><?php echo e($obra->caract_descrip); ?></td>
</tr>
<?php endif; // Entrust::can ?>
<?php if (\Entrust::can(['Consulta_General_Basica','Consulta_General_Avanzada_2','Consulta_Externa'])) : ?>
<tr>
  <td style="font-size:20px;">Temporalidad:</td>
  <td style="font-size:20px;"><?php echo e($obra->temp_obra); ?></td>
</tr>
<?php if($obra->año != NULL): ?>
<tr>
  <td style="font-size:20px;">Año de la Obra:</td>
  <td style="font-size:20px;"><?php echo e($obra->año); ?></td>
</tr>
<?php endif; ?>
<?php if($obra->epoca_obra != NULL): ?>
<tr>
  <td style="font-size:20px;">Epoca de la Obra:</td>
  <td style="font-size:20px;"><?php echo e($obra->epoca_obra); ?></td>
</tr>
<?php endif; ?>
<?php endif; // Entrust::can ?>
<?php if (\Entrust::can(['Consulta_General_Basica','Consulta_General_Avanzada_2'])) : ?>
<?php if($obra->año_confirm != NULL): ?>
<tr>
  <td style="font-size:20px;">Año de la Obra Confirmado</td>
  <td style="font-size:20px;"><?php echo e($obra->año_confirm); ?></td>
</tr>
<?php endif; ?>
<?php if($obra->año_aproxi != NULL): ?>
<tr>
  <td style="font-size:20px;">Año de la Obra Aproximado:</td>
  <td style="font-size:20px;"><?php echo e($obra->año_aproxi); ?></td>
</tr>
<?php endif; ?>
<?php if($obra->epoca_confirm != NULL): ?>
<tr>
  <td style="font-size:20px;">Epoca de la Obra Confirmada:</td>
  <td style="font-size:20px;"><?php echo e($obra->epoca_confirm); ?></td>
</tr>
<?php endif; ?>
<?php if($obra->epoca_aproxi != NULL): ?>
<tr>
  <td style="font-size:20px;">Epoca de la Obra Aproximada:</td>
  <td style="font-size:20px;"><?php echo e($obra->epoca_aproxi); ?></td>
</tr>
<?php endif; ?>
<?php endif; // Entrust::can ?>
</table>
<p class="saltodepagina" />
<img  width="200px" src="images/Logotipo_ECRO_Gris.png" >
<?php if (\Entrust::can(['Consulta_General_Basica','Consulta_General_Avanzada_2'])) : ?>



<table style="width:100%" border="0" align="center" cellspacing="6" cellpadding="6">
<tr ><th colspan="1"style="text-align:center;background-color: #7C858C; color:white;"><h3>Información de indentificación</h3></th></tr>
</table>
<table style="width:100%" border="0" align="center" cellspacing="6" cellpadding="6">

  <?php endif; // Entrust::can ?>
<?php if (\Entrust::can('Consulta_General_Avanzada_2')) : ?>
<tr>
  <td style="font-size:20px; width:52%;">Forma de Ingreso:</td>
    <td style="font-size:20px;"><?php echo e($obra->forma_ingreso); ?></td>
</tr>
<?php endif; // Entrust::can ?>
<?php if (\Entrust::can(['Consulta_General_Basica','Consulta_General_Avanzada_2'])) : ?>
<tr>
  <td style="font-size:20px;">Sector:</td>
  <td style="font-size:20px;"><?php echo e($obra->sector_obra); ?></td>
</tr>
<?php endif; // Entrust::can ?>
<?php if (\Entrust::can('Consulta_General_Avanzada_2')) : ?>
<tr>
  <td style="font-size:20px;">Responsable de la ECRO:</td>
  <td style="font-size:20px;"><?php echo e($obra->respon_ecro); ?></td>
</tr>
<tr>
  <td style="font-size:20px;">Fecha de Entrada:</td>
  <td style="font-size:20px;"><?php echo e($obra->fecha_de_entrada); ?></td>
</tr>
<?php endif; // Entrust::can ?>
<?php if (\Entrust::can(['Consulta_General_Basica','Consulta_General_Avanzada_2'])) : ?>
<tr>
  <td style="font-size:20px;">Nombre del Proyecto de la Obra:</td>
  <td style="font-size:20px;"><?php echo e($obra->proyecto_obra); ?></td>
</tr>
<?php endif; // Entrust::can ?>
<?php if (\Entrust::can('Consulta_General_Avanzada_2')) : ?>
<tr>
  <td style="font-size:20px;">No. de Proyecto de la Obra:</td>
  <td style="font-size:20px;"><?php echo e($obra->no_proyec_obra); ?></td>
</tr>
<?php endif; // Entrust::can ?>
<?php if (\Entrust::can(['Consulta_General_Basica','Consulta_General_Avanzada_2'])) : ?>
<tr>
<td style="font-size:20px;">Año de Temporada de Trabajo:</td>
  <td style="font-size:20px;"><?php echo e($obra->año_trabajo_obra); ?></td>
</tr>
<tr>
    <td style="font-size:20px;">Temporada de Trabajo:</td>
  <td style="font-size:20px;"><?php echo e($obra->temporada_trabajo); ?></td>
</tr>
<?php endif; // Entrust::can ?>
<?php if (\Entrust::can(['Consulta_General_Avanzada_2'])) : ?>
<tr>
  <td style="font-size:20px;">Fecha de Salida:</td>
  <td style="font-size:20px;"><?php echo e($obra->fecha_de_salida); ?></td>
</tr>
<?php endif; // Entrust::can ?>


</table><br><br><br><br><br>
      
      
   
</form>
                            
  

   

</div>
                </div>
            </div>
        </div>
    </div>