 <?php
          $obras_ver = $obras->first();
          ?>
<?php $__env->startSection('htmlheader_title'); ?>
    <?php echo e(trans('adminlte_lang::message.home')); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('main-content'); ?>

<div class="box">
    <div class="box-body"  >
        <div class="panel">
         
            <h1 align="center">Obra: <?php echo e($obras_ver->id_de_obras); ?> </h1>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <strong>Vaya!</strong> Parece que algo hiciste mal.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<form action="<?php echo e(route('Obras.actualizar', $obras_ver->id)); ?>" method="POST" class="form-inline text-left">
    <?php echo csrf_field(); ?>
  
     <BR>
     <div align="center">
            <table id="1" style="width: 65%" border="0" align="center">
<tr ><th colspan="5"style="text-align:center;background-color: #7C858C; color:white;"><h3>Datos Generales</h3></th></tr>

<?php if (\Entrust::can('Consulta_General_Basica','Consulta_General_Avanzada_2')) : ?>
<?php if($obras_ver->id_de_obras != NULL): ?>
  <tr>
    <td style="font-size:25px; width:700px;">ID de Obra:</td>
    <td style="font-size:25px;"><input type="text" readonly name="id_de_obras" class="form-control" placeholder="ID de la Obra"  value="<?php echo e($obras_ver->id_de_obras); ?>" style="width:550px; font-size:18px;"></td>
  </tr>
  <?php endif; ?>
<?php endif; // Entrust::can ?>
<?php if (\Entrust::can(['Consulta_General_Basica','Consulta_General_Avanzada_2','Consulta_Externa'])) : ?>
<tr>
  <td style="font-size:25px;">Titulo de la Obra:</td>
    <td style="font-size:25px;"><input type="text" readonly name="titulo_obra" class="form-control" placeholder="Titulo de la Obra" value="<?php echo e($obras_ver->titulo_obra); ?>" style="width:550px; font-size:18px;"></td>
</tr>
<?php if($obras_ver->autor != NULL): ?>
<tr>
  <td style="font-size:25px;">Autor:</td>
  <td style="font-size:25px;"><input type="text" readonly class="form-control"  name="autor" placeholder="Autor" value="<?php echo e($obras_ver->autor); ?>" style="width:550px; font-size:18px;"></td>
</tr>
<?php endif; ?>
<?php if($obras_ver->cultura != NULL): ?>
<tr>
  <td style="font-size:25px;">Cultura:</td>
  <td style="font-size:25px;"><input type="text" readonly class="form-control"  name="cultura" placeholder="Cultura" value="<?php echo e($obras_ver->cultura); ?>" style="width:550px; font-size:18px;"></td>
</tr>
<?php endif; ?>
<tr>
  <td style="font-size:25px;">Tipo de Bien Cultural:</td>
  <td style="font-size:25px;"><input type="text" readonly class="form-control" name="tipo_bien_cultu" value="<?php echo e($obras_ver->tipo_bien_cultu); ?>" style="width:550px; font-size:18px;">
  </td>
</tr>

<tr>
  <td style="font-size:25px;">Tipo de Objeto de la Obra:</td>
  <td style="font-size:25px;"><input type=""  type="text" name="tipo_obj_obra" readonly class="form-control" placeholder="Tipo de Objeto de la Obra" value="<?php echo e($obras_ver->tipo_obj_obra); ?>" style="width:550px; font-size:18px;">
  </td>
</tr>
<?php endif; // Entrust::can ?>
<?php if (\Entrust::can('Consulta_General_Basica','Consulta_General_Avanzada_2')) : ?>
<tr>
  <td style="font-size:25px;">Lugar de Procedencia Actual:</td>
  <td style="font-size:25px;"><input type="text" readonly class="form-control" placeholder="Lugar de Procedencia Actual" name="lugar_proce_act"  value="<?php echo e($obras_ver->lugar_proce_act); ?>" style="width:550px; font-size:18px;"></td>
</tr>
<?php endif; // Entrust::can ?>
<?php if (\Entrust::can('Consulta_General_Avanzada_2')) : ?>
<tr>
  <td style="font-size:25px;">Lugar de Procedencia Original:</td>
  <td style="font-size:25px;"><input type="text" readonly class="form-control"  name="lugar_proce_ori" placeholder="Lugar de Procedencia Original" value="<?php echo e($obras_ver->lugar_proce_ori); ?>" style="width:550px; font-size:18px;"></td>
</tr>
<tr>
    <td style="font-size:25px;">No. de inventario de la Obra o Códigos de Procedencia:</td>
    <td style="font-size:25px;"><input type="text" readonly class="form-control"  name="no_inv_obra" placeholder="No. de inventario de la Obra o Códigos de Procedencia" value="<?php echo e($obras_ver->no_inv_obra); ?>" style="width:550px; font-size:18px;"></td>
  </tr>
  <?php endif; // Entrust::can ?>
<?php if (\Entrust::can('Consulta_General_Basica','Consulta_General_Avanzada_2')) : ?>
<tr>
  <td style="font-size:25px;">Características Descriptivas:</td>
  <td style="font-size:25px;"><input type="text" readonly name="caract_descrip" class="form-control" placeholder="Características Descriptivas" value="<?php echo e($obras_ver->caract_descrip); ?>" style="width:550px; font-size:18px;"></td>
</tr>
<?php endif; // Entrust::can ?>
<?php if (\Entrust::can(['Consulta_General_Basica','Consulta_General_Avanzada_2','Consulta_Externa'])) : ?>
<tr>
  <td style="font-size:25px;">Temporalidad:</td>
  <td style="font-size:18px;"><input  type="text" readonly name="temp_obra" class="form-control" placeholder="Temporalidad" value="<?php echo e($obras_ver->temp_obra); ?>" style="width:550px; font-size:18px;"></td>
</tr>
<?php if($obras_ver->año != NULL): ?>
<tr>
  <td style="font-size:25px;">Año de la Obra:</td>
  <td style="font-size:23px;"><input type="text" readonly name="año" class="form-control" placeholder="Año de la Obra" value="<?php echo e($obras_ver->año); ?>" style="width:550px; font-size:18px;"></td>
</tr>
<?php endif; ?>
<?php if($obras_ver->epoca_obra != NULL): ?>
<tr>
  <td style="font-size:25px;">Epoca de la Obra:</td>
  <td style="font-size:25px;"><input  type="text" name="epoca_obra" readonly class="form-control" placeholder="Epoca de la Obra" value="<?php echo e($obras_ver->epoca_obra); ?>" style="width:550px; font-size:18px;"></td>
</tr>
<?php endif; ?>
<?php endif; // Entrust::can ?>
<?php if (\Entrust::can('Consulta_General_Basica','Consulta_General_Avanzada_2')) : ?>
<?php if($obras_ver->año_confirm != NULL): ?>
<tr>
  <td style="font-size:25px;">Año de la Obra Confirmado</td>
  <td style="font-size:25px;"><input type="text" readonly class="form-control" name="año_confirm"  value="<?php echo e($obras_ver->año_confirm); ?>"  style="width:550px; font-size:18px;"></td>
</tr>
<?php endif; ?>
<?php if($obras_ver->año_aproxi != NULL): ?>
<tr>
  <td style="font-size:25px;">Año de la Obra Aproximado:</td>
  <td style="font-size:25px;"><input type="text" class="form-control" readonly name="año_aproxi" value="<?php echo e($obras_ver->año_aproxi); ?>" style="width:550px; font-size:18px;"></td>
</tr>
<?php endif; ?>
<?php if($obras_ver->epoca_confirm != NULL): ?>
<tr>
  <td style="font-size:25px;">Epoca de la Obra Confirmada:</td>
  <td><input type="text"  class="form-control" name="epoca_confirm" readonly value="<?php echo e($obras_ver->epoca_confirm); ?>" style="width:550px; font-size:18px;">
  </td>
</tr>
<?php endif; ?>
<?php if($obras_ver->epoca_aproxi != NULL): ?>
<tr>
  <td style="font-size:25px;">Epoca de la Obra Aproximada:</td>
  <td style="font-size:25px;"><input type="text" readonly class="form-control" name="epoca_aproxi" value="<?php echo e($obras_ver->epoca_aproxi); ?>" style="width:550px; font-size:18px;">
  </td>
</tr>
<?php endif; ?>
<?php endif; // Entrust::can ?>


</table>

<br>



<table style="width: 65%" border="0" align="center">
<?php if (\Entrust::can('Consulta_General_Basica','Consulta_General_Avanzada_2')) : ?>
<tr ><th colspan="5"style="text-align:center;background-color: #7C858C; color:white;"><h3>Información de indentificación</h3></th></tr>
  <?php endif; // Entrust::can ?>
<?php if (\Entrust::can('Consulta_General_Avanzada_2')) : ?>
<tr>
  <td style="font-size:25px;">Forma de Ingreso:</td>
    <td style="font-size:25px;"><input readonly type="text" class="form-control"  name="forma_ingreso" placeholder="Forma de Ingreso" value="<?php echo e($obras_ver->forma_ingreso); ?>" style="width:550px; font-size:18px;"></td>
</tr>
<?php endif; // Entrust::can ?>
<?php if (\Entrust::can('Consulta_General_Basica','Consulta_General_Avanzada_2')) : ?>
<tr>
  <td style="font-size:25px;">Sector:</td>
  <td style="font-size:25px;"><input type="text" readonly class="form-control" name="sector_obra" value="<?php echo e($obras_ver->sector_obra); ?>" style="width:550px; font-size:18px;">
                           </td>
</tr>
<?php endif; // Entrust::can ?>
<?php if (\Entrust::can('Consulta_General_Avanzada_2')) : ?>
<tr>
  <td style="font-size:25px;">Responsable de la ECRO:</td>
  <td style="font-size:25px;"><input type="text" class="form-control" readonly name="respon_ecro" placeholder="Responsable de la ECRO" value="<?php echo e($obras_ver->respon_ecro); ?>" style="width:550px; font-size:18px;"></td>
</tr>
<tr>
  <td style="font-size:25px;">Fecha de Entrada:</td>
  <td style="font-size:25px;"><input type="date" class="form-control date" readonly name="fecha_de_entrada" placeholder="mm/dd/aaaa (Fecha de entrada)" value="<?php echo e($obras_ver->fecha_de_entrada); ?>" style="width:550px; font-size:18px;"></td>
</tr>
<?php endif; // Entrust::can ?>
<?php if (\Entrust::can('Consulta_General_Basica','Consulta_General_Avanzada_2')) : ?>
<tr>
  <td style="font-size:25px;">Nombre del Proyecto de la Obra:</td>
  <td style="font-size:25px;"><input type="text" class="form-control" readonly name="proyecto_obra" placeholder="Nombre del Proyecto de la Obra" value="<?php echo e($obras_ver->proyecto_obra); ?>" style="width:550px; font-size:18px;"></td>
</tr>
<?php endif; // Entrust::can ?>
<?php if (\Entrust::can('Consulta_General_Avanzada_2')) : ?>
<tr>
  <td style="font-size:25px;">No. de Proyecto de la Obra:</td>
  <td style="font-size:25px;"><input type="text" class="form-control" readonly placeholder="No. de Proyecto de la Obra" name="no_proyec_obra"  value="<?php echo e($obras_ver->no_proyec_obra); ?>" style="width:550px; font-size:18px;"></td>
</tr>
<?php endif; // Entrust::can ?>
<?php if (\Entrust::can('Consulta_General_Basica','Consulta_General_Avanzada_2')) : ?>

 <?php $__currentLoopData = $obras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anio_de_trabajo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td style="font-size:25px;">Año de Temporada de Trabajo:</td>
  <td style="font-size:25px; width:550px"><input type="text" readonly class="form-control" placeholder="Año de Temporada de Trabajo" name="año_trabajo_obra" value="<?php echo e($anio_de_trabajo->anio_temporada_trabajo); ?>" style="width:550px; font-size:18px;"></td>
</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $tempo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $temporadas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<td style="font-size:25px;">Temporada de trabajo:</td>
  <td style="font-size:25px; width:550px"><input type="text" readonly class="form-control" placeholder="Año de Temporada de Trabajo" name="temporada_de_trabajo" value="<?php echo e($temporadas->temporada_trabajo); ?>" style="width:550px; font-size:18px;"></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; // Entrust::can ?>
<?php if (\Entrust::can('Consulta_General_Avanzada_2')) : ?>
<tr>
  <td style="font-size:25px;">Fecha de Salida:</td>
  <td><input type="date" class="form-control pull-right" name="fecha_de_salida" readonly placeholder="mm/dd/aaaa (Fecha de salida)" value="<?php echo e($obras_ver->fecha_de_salida); ?>" style="width:550px; font-size:18px;"></td>
</tr>
<?php endif; // Entrust::can ?>


</table><br><br><br><br><br>
      </div>
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <a href="<?php echo e(route('Obras.index')); ?>" class="btn btn-danger btn-sm">Regresar</a>
        </div>
    
   
</form>
                            
  

   

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>