 
<?php $__env->startSection('main-content'); ?>

<?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
<?php endif; ?>



<div class="box">
	<div class="box-body">
		<div class="panel">
			<div align="center">
			<h1>
			Obras Registradas
			<?php echo e(Form::open(['route' => 'Obra.strc', 'method' => 'GET', 'class' => 'form-inline pull-right'])); ?>

			<div class="form-group">
				<?php echo e(Form::text('busqueda', null, ['class' => 'form-control', 'placeholder' => 'Titulo'])); ?>

			</div>
			<div class="form-group">
				<button type="submit" class="btn btn-default">
					<span class="glyphicon glyphicon-search"></span>
				</button>
				
			</div>

			<?php echo e(Form::close()); ?>

			</h1></div>
		</div>

		<div style="overflow-x: auto; ">
			<div>
				<table id="tablaObras" class="table table-hover" role="grid" >
					<thead >
        				<tr>
        					<th>id</th>
        					<th>Obra</th>
        					<th>Año</th>
        					<th>Epoca</th>
        					<th>Temporalidad</th>
        					<th>Tipo de Objeto</th>
				            <th>Sector de la obra</th>
            				<th>Acción</th>
        				</tr>
       				</thead>
       				<tbody>
       					<?php $__currentLoopData = $Obras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Obra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       					<?php if($Obra->sector_obra == 'Seminario Taller de Restauración de Escultura Policromada' || $Obra->sector_obra == 'Servicio Social - Seminario Taller de Restauración de Escultura Policromada' || $Obra->sector_obra == 'Práctica de Campo - Seminario Taller de Restauración de Escultura Policromada' ): ?>
       					
       					<tr>
       						<td><?php echo e($Obra->id_de_obras); ?></td>
				            <td><?php echo e($Obra->titulo_obra); ?></td>
				            <td><?php echo e($Obra->año); ?></td>
				            <td><?php echo e($Obra->epoca_obra); ?></td>
				            <td><?php echo e($Obra->temp_obra); ?></td>
				            <td><?php echo e($Obra->tipo_obj_obra); ?></td>
				            <td><?php echo e($Obra->sector_obra); ?></td>
				            <td>
				            <td><a href="<?php echo e(route('Obras.show', $Obra->id)); ?>" class="btn btn-block btn-info btn-xs" style="width:70px;">Ver mas</a></td>
				            

				            <?php if (\Entrust::can('Editar_Registro_Bloqueo_Redireccion')) : ?>
		                    <td><a href="<?php echo e(route('Obras.editar', $Obra->id)); ?>" class="btn btn-block btn-warning btn-xs" style="width:70px;">Editar</a></td>
		                    <?php endif; // Entrust::can ?>
		                    
		                    <td>


							<form id="delete-<?php echo e($Obra->id); ?>" action="<?php echo e(route('Obras.destroy', $Obra->id)); ?>" method="POST">
								<a href="javascript:document.getElementById('delete-<?php echo e($Obra->id); ?>').submit()" class="btn btn-block btn-danger btn-xs" onclick="return confirm('¿Seguro que deseas eliminarlo?')" style="width:70px;">Eliminar</a>
		                    <?php echo method_field('delete'); ?>
		 					<?php echo csrf_field(); ?>
                			</form>
  							

		                    </td>
		                    
		                    <td><a href="<?php echo e(route('analisisg.create', $Obra->id)); ?>" class="btn btn-block btn-success btn-xs" style="width:90px;">Agregar ficha</a></td>
		                   
							<td><a target="_blank" href="<?php echo e(route('Obras.pdf', $Obra->id)); ?>" class="btn btn-block btn-success btn-xs" style="width:90px;">Imprimir</a></td>

            				</td>
            				
        				</tr> 
        				<?php endif; ?>
          				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    				</tbody>
       					
    			</table>
                <div align="center">
                <?php echo $Obras->links(); ?>  
                </div>
  
		</div>
	</div>				 	
  </div>
</div>
   
<script src="../../bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>

      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>